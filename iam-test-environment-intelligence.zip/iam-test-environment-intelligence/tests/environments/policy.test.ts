import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { approvalRequirement, checkAccess } from '../../src/server/environments/policy.ts';
import { NOW, YESTERDAY, actor, anonymous, env } from './fixtures.ts';

describe('checkAccess — organizer side', () => {
  it('owners and co-organizers manage, even drafts', () => {
    for (const role of ['OWNER', 'CO_ORGANIZER'] as const) {
      const d = checkAccess(actor({ organizerRole: role }), env({}, { status: 'DRAFT' }), NOW);
      assert.deepEqual(d, { visible: true, action: 'MANAGE', reason: 'ORGANIZER' });
    }
  });
  it('owning-org admins and platform admins manage', () => {
    assert.equal(checkAccess(actor({ isOwningOrgAdmin: true }), env({ accessModel: 'PRIVATE' }), NOW).action, 'MANAGE');
    assert.equal(checkAccess(actor({ isPlatformAdmin: true }), env({ accessModel: 'PRIVATE' }), NOW).action, 'MANAGE');
  });
  it('check-in staff only get check-in', () => {
    assert.equal(checkAccess(actor({ organizerRole: 'CHECKIN_STAFF' }), env(), NOW).action, 'CHECK_IN_ONLY');
  });
});

describe('checkAccess — publication state', () => {
  it('drafts and unpublished environments are hidden (404) from everyone else', () => {
    for (const status of ['DRAFT', 'UNPUBLISHED', 'ARCHIVED'] as const) {
      assert.deepEqual(checkAccess(actor(), env({}, { status }), NOW), { visible: false, action: 'NONE', reason: 'NOT_FOUND' });
    }
  });
  it('a cancelled environment stays visible to its participants only', () => {
    assert.equal(checkAccess(actor({ participationStatus: 'CONFIRMED' }), env({}, { status: 'CANCELLED' }), NOW).visible, true);
    assert.equal(checkAccess(actor(), env({}, { status: 'CANCELLED' }), NOW).visible, false);
  });
});

describe('checkAccess — PUBLIC', () => {
  it('open registration for signed-in users', () => {
    assert.deepEqual(checkAccess(actor(), env(), NOW), { visible: true, action: 'REGISTER', reason: 'OPEN_REGISTRATION' });
  });
  it('anonymous visitors see it but must sign in', () => {
    assert.deepEqual(checkAccess(anonymous(), env(), NOW), { visible: true, action: 'NONE', reason: 'SIGN_IN_REQUIRED' });
  });
  it('REQUEST mode → request, INVITE_ONLY → invitation required', () => {
    assert.equal(checkAccess(actor(), env({ registrationMode: 'REQUEST' }), NOW).action, 'REQUEST');
    assert.deepEqual(checkAccess(actor(), env({ registrationMode: 'INVITE_ONLY' }), NOW), {
      visible: true,
      action: 'NONE',
      reason: 'INVITATION_REQUIRED',
    });
  });
  it('registration closes at the start time', () => {
    assert.equal(checkAccess(actor(), env({}, { startsAt: YESTERDAY }), NOW).reason, 'REGISTRATION_CLOSED');
  });
  it('hubs (no start time) never close', () => {
    assert.equal(checkAccess(actor(), env({}, { kind: 'HUB', startsAt: null }), NOW).action, 'REGISTER');
  });
});

describe('checkAccess — PRIVATE', () => {
  it('uninvited users get 404, not 403', () => {
    assert.deepEqual(checkAccess(actor(), env({ accessModel: 'PRIVATE' }), NOW), { visible: false, action: 'NONE', reason: 'NOT_FOUND' });
    assert.equal(checkAccess(anonymous(), env({ accessModel: 'PRIVATE' }), NOW).visible, false);
  });
  it('invitees can respond', () => {
    assert.equal(checkAccess(actor({ hasOpenInvitation: true }), env({ accessModel: 'PRIVATE' }), NOW).action, 'RESPOND_TO_INVITATION');
  });
  it('participants keep seeing it; INVITED participants respond', () => {
    assert.equal(checkAccess(actor({ participationStatus: 'CONFIRMED' }), env({ accessModel: 'PRIVATE' }), NOW).action, 'OWN_PARTICIPATION');
    assert.equal(checkAccess(actor({ participationStatus: 'INVITED' }), env({ accessModel: 'PRIVATE' }), NOW).action, 'RESPOND_TO_INVITATION');
  });
  it('a removed participant no longer sees it', () => {
    assert.equal(checkAccess(actor({ participationStatus: 'REMOVED' }), env({ accessModel: 'PRIVATE' }), NOW).visible, false);
  });
});

describe('checkAccess — CURATED', () => {
  it('never offers open registration, only a request', () => {
    const d = checkAccess(actor(), env({ accessModel: 'CURATED', registrationMode: 'OPEN' }), NOW);
    assert.equal(d.action, 'REQUEST');
  });
  it('hidden curated environments are 404 unless invited', () => {
    assert.equal(checkAccess(actor(), env({ accessModel: 'CURATED', discoverable: false }), NOW).visible, false);
    assert.equal(checkAccess(actor({ hasOpenInvitation: true }), env({ accessModel: 'CURATED', discoverable: false }), NOW).action, 'RESPOND_TO_INVITATION');
  });
});

describe('checkAccess — COMMUNITY', () => {
  const community = { accessModel: 'COMMUNITY' as const, communityHubIds: ['hub-amf'], discoverable: false };

  it('members of the community hub can register', () => {
    assert.deepEqual(checkAccess(actor({ hubIds: ['hub-amf'] }), env(community), NOW), {
      visible: true,
      action: 'REGISTER',
      reason: 'COMMUNITY_MEMBER',
    });
  });
  it('non-members do not see a non-discoverable community environment', () => {
    assert.equal(checkAccess(actor({ hubIds: ['hub-other'] }), env(community), NOW).visible, false);
  });
  it('non-members of a discoverable one see it but cannot join', () => {
    assert.equal(checkAccess(actor(), env({ ...community, discoverable: true }), NOW).reason, 'MEMBERS_ONLY');
  });
  it('nominated guests may request when the guest policy allows', () => {
    const d = checkAccess(actor({ isNominatedGuest: true }), env({ ...community, guestPolicy: 'MEMBERS_PLUS_N', guestsPerMember: 1 }), NOW);
    assert.deepEqual(d, { visible: true, action: 'REQUEST', reason: 'NOMINATED_GUEST' });
    assert.equal(checkAccess(actor({ isNominatedGuest: true }), env(community), NOW).visible, false);
  });
  it('partner-hub members may request only with ALLOWED_HUBS', () => {
    const partner = actor({ hubIds: ['hub-utr'] });
    assert.equal(checkAccess(partner, env({ ...community, crossCommunity: 'ALLOWED_HUBS', allowedPartnerHubIds: ['hub-utr'] }), NOW).reason, 'PARTNER_HUB_MEMBER');
    assert.equal(checkAccess(partner, env({ ...community, crossCommunity: 'ON_REQUEST', allowedPartnerHubIds: ['hub-utr'] }), NOW).visible, false);
  });
});

describe('approvalRequirement', () => {
  const facts = { hubIds: ['hub-amf'], audienceCodes: ['audience.entrepreneur'] };

  it('AUTO_WITHIN_CONDITIONS confirms only when every condition holds', () => {
    const e = env({
      autoConditions: [
        { type: 'hub_membership', hubIds: ['hub-amf'] },
        { type: 'profile_type', audienceCodes: ['audience.entrepreneur'] },
        { type: 'closes_hours_before_start', hours: 24 },
      ],
    });
    assert.deepEqual(approvalRequirement(e, 'SELF_REGISTRATION', facts, NOW), { required: 'NONE', unmetConditions: [] });

    // Remove one fact at a time: each flips the outcome to ORGANIZER and names the failed condition.
    assert.deepEqual(approvalRequirement(e, 'SELF_REGISTRATION', { ...facts, hubIds: [] }, NOW), {
      required: 'ORGANIZER',
      unmetConditions: ['hub_membership'],
    });
    assert.deepEqual(approvalRequirement(e, 'SELF_REGISTRATION', { ...facts, audienceCodes: ['audience.student'] }, NOW), {
      required: 'ORGANIZER',
      unmetConditions: ['profile_type'],
    });
    const lateNow = new Date('2026-11-26T00:00:00Z'); // 19 h before start
    assert.deepEqual(approvalRequirement(e, 'SELF_REGISTRATION', facts, lateNow), {
      required: 'ORGANIZER',
      unmetConditions: ['closes_hours_before_start'],
    });
  });
  it('MANUAL → organizer; INVITATION_ONLY → only via invitation', () => {
    assert.equal(approvalRequirement(env({ approvalMode: 'MANUAL' }), 'REQUEST', facts, NOW).required, 'ORGANIZER');
    assert.equal(approvalRequirement(env({ approvalMode: 'INVITATION_ONLY' }), 'SELF_REGISTRATION', facts, NOW).required, 'INVITATION');
  });
  it('personal invitations and organizer additions are their own approval', () => {
    const manual = env({ approvalMode: 'MANUAL' });
    assert.equal(approvalRequirement(manual, 'PERSONAL_INVITATION_ACCEPTANCE', facts, NOW).required, 'NONE');
    assert.equal(approvalRequirement(manual, 'ORGANIZER_ADDED', facts, NOW).required, 'NONE');
  });
  it('distribution acceptances follow the distribution approval method', () => {
    assert.equal(approvalRequirement(env(), 'DISTRIBUTION_INVITATION_ACCEPTANCE', facts, NOW, true).required, 'ORGANIZER');
    assert.equal(approvalRequirement(env(), 'DISTRIBUTION_INVITATION_ACCEPTANCE', facts, NOW, false).required, 'NONE');
  });
  it('cross-community participation always needs an organizer', () => {
    assert.equal(approvalRequirement(env(), 'CROSS_COMMUNITY', facts, NOW).required, 'ORGANIZER');
  });
});
