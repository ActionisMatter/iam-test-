import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { checkEligibility, parseEligibilityRules } from '../../src/server/environments/eligibility.ts';
import { NOW, profile } from './fixtures.ts';

describe('checkEligibility', () => {
  it('no rules → eligible', () => {
    assert.deepEqual(checkEligibility(profile(), [], NOW), { eligible: true, unmet: [] });
  });

  it('required skill, optionally verified', () => {
    const rule = { type: 'required_skill' as const, skillId: 'ux', label: 'UX design', mustBeVerified: true };
    assert.equal(checkEligibility(profile(), [rule], NOW).unmet[0]?.message, 'Requires the skill UX design.');
    const unverified = profile({ skills: [{ skillId: 'ux', level: 'level.advanced', verified: false }] });
    assert.equal(checkEligibility(unverified, [rule], NOW).unmet[0]?.message, 'Requires a verified UX design skill.');
    const verified = profile({ skills: [{ skillId: 'ux', level: 'level.advanced', verified: true }] });
    assert.equal(checkEligibility(verified, [rule], NOW).eligible, true);
  });

  it('minimum level, overall or per skill', () => {
    const p = profile({ skills: [{ skillId: 'ux', level: 'level.intermediate', verified: false }, { skillId: 'go', level: 'level.beginner', verified: false }] });
    assert.equal(checkEligibility(p, [{ type: 'min_experience_level', level: 'level.intermediate' }], NOW).eligible, true);
    assert.equal(checkEligibility(p, [{ type: 'min_experience_level', level: 'level.intermediate', skillId: 'go' }], NOW).eligible, false);
    assert.equal(checkEligibility(profile(), [{ type: 'min_experience_level', level: 'level.open' }], NOW).eligible, true);
  });

  it('profile type, hub, organization, location, prerequisite', () => {
    const p = profile({ audienceCodes: ['audience.creator'], hubIds: ['hub-amf'], organizationIds: ['org-1'], completedEnvironmentIds: ['env-part1'] });
    const rules = [
      { type: 'profile_type' as const, audienceCodes: ['audience.creator'] },
      { type: 'hub_membership' as const, hubIds: ['hub-amf'], label: 'Amersfoort Hub' },
      { type: 'organization_membership' as const, organizationIds: ['org-1'], label: 'Partner X' },
      { type: 'location' as const, countryCodes: ['NL', 'BE'] },
      { type: 'prerequisite_environment' as const, environmentId: 'env-part1', label: 'Training part 1' },
    ];
    assert.equal(checkEligibility(p, rules, NOW).eligible, true);
    const result = checkEligibility(profile({ countryCode: 'DE' }), rules, NOW);
    assert.equal(result.eligible, false);
    assert.deepEqual(result.unmet.map((u) => u.type), ['profile_type', 'hub_membership', 'organization_membership', 'location', 'prerequisite_environment']);
  });

  it('age minimum uses birth year only and is conservative', () => {
    const rule = [{ type: 'age_minimum' as const, years: 18 }];
    assert.equal(checkEligibility(profile({ birthYear: null }), rule, NOW).eligible, false);
    assert.equal(checkEligibility(profile({ birthYear: 2007 }), rule, NOW).eligible, true); // at least 18 in 2026
    assert.equal(checkEligibility(profile({ birthYear: 2008 }), rule, NOW).eligible, false); // may still be 17
  });

  it('every unmet rule comes with a message (never silent)', () => {
    const r = checkEligibility(profile(), [{ type: 'hub_membership', hubIds: ['x'], label: 'X Hub' }], NOW);
    assert.equal(r.unmet[0]?.message, 'Requires membership of X Hub.');
  });
});

describe('parseEligibilityRules', () => {
  it('accepts the closed set of rule types', () => {
    const { rules, errors } = parseEligibilityRules([
      { type: 'required_skill', skillId: 'ux', label: 'UX', mustBeVerified: false },
      { type: 'location', countryCodes: ['NL'] },
      { type: 'age_minimum', years: 18 },
    ]);
    assert.deepEqual(errors, []);
    assert.equal(rules.length, 3);
  });
  it('rejects rule types outside the set, including special-category data', () => {
    for (const type of ['religion', 'health_condition', 'ethnicity', 'gender', 'nationality', 'engagement_score', 'relevance']) {
      const { rules, errors } = parseEligibilityRules([{ type, value: 'x' }]);
      assert.equal(rules.length, 0, type);
      assert.equal(errors.length, 1, type);
    }
  });
  it('rejects malformed rules and non-legal age limits', () => {
    assert.equal(parseEligibilityRules([{ type: 'location', countryCodes: ['Netherlands'] }]).errors.length, 1);
    assert.equal(parseEligibilityRules([{ type: 'age_minimum', years: 30 }]).errors.length, 1);
    assert.equal(parseEligibilityRules([{ type: 'profile_type', audienceCodes: ['founders'] }]).errors.length, 1);
    assert.deepEqual(parseEligibilityRules({}).errors, ['Eligibility rules must be a list.']);
  });
});
