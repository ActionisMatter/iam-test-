import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { assessRelevance, mainCategoryOf } from '../../src/server/environments/relevance.ts';
import { checkAccess } from '../../src/server/environments/policy.ts';
import { NOW, actor, audienceProfile, env, profile } from './fixtures.ts';

describe('assessRelevance', () => {
  it('no overlap → NONE with no reasons', () => {
    const r = assessRelevance(profile({ city: 'Groningen', countryCode: 'DE' }), audienceProfile({ categoryCodes: ['creative.music'] }));
    assert.deepEqual(r, { level: 'NONE', reasons: [] });
  });

  it('strong overlap → HIGH, with every reason listed', () => {
    const p = profile({
      interestCodes: ['technology.artificial_intelligence', 'business.startups'],
      audienceCodes: ['audience.entrepreneur'],
      skills: [{ skillId: 'ml', level: 'level.advanced', verified: true }],
      hubIds: ['hub-amf'],
    });
    const e = audienceProfile({
      categoryCodes: ['technology.artificial_intelligence', 'business.startups'],
      audienceCodes: ['audience.entrepreneur'],
      targetSkillIds: ['ml'],
      communityHubIds: ['hub-amf'],
    });
    const r = assessRelevance(p, e);
    assert.equal(r.level, 'HIGH');
    assert.deepEqual(r.reasons.map((x) => x.kind), ['shared_interest', 'audience_match', 'skill_match', 'hub_member', 'same_city']);
  });

  it('same main category counts as a weaker, related interest', () => {
    const r = assessRelevance(profile({ interestCodes: ['technology.data'], city: null, countryCode: null }), audienceProfile({ categoryCodes: ['technology.artificial_intelligence'] }));
    assert.deepEqual(r.reasons, [{ kind: 'related_interest', codes: ['technology'] }]);
    assert.equal(r.level, 'LOW');
  });

  it('location is ignored for online environments', () => {
    const r = assessRelevance(profile(), audienceProfile({ locationScope: 'scope.online' }));
    assert.equal(r.level, 'NONE');
  });

  it('never exposes a numeric score', () => {
    const r = assessRelevance(profile({ interestCodes: ['business'] }), audienceProfile({ categoryCodes: ['business'] }));
    assert.deepEqual(Object.keys(r).sort(), ['level', 'reasons']);
  });

  it('R1: relevance NONE does not stop someone who is allowed in', () => {
    const relevance = assessRelevance(profile({ city: null, countryCode: null }), audienceProfile({ categoryCodes: ['creative.music'] }));
    assert.equal(relevance.level, 'NONE');
    assert.equal(checkAccess(actor(), env(), NOW).action, 'REGISTER');
  });

  it('mainCategoryOf', () => {
    assert.equal(mainCategoryOf('technology.data'), 'technology');
    assert.equal(mainCategoryOf('business'), 'business');
  });
});
