import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { ParticipationStatus } from '../../src/domain/environments/types.ts';
import {
  attendanceRate,
  canTransition,
  computeCapacity,
  decideReservation,
  nextForPromotion,
  releasesPlace,
  replacementRate,
} from '../../src/server/environments/capacity.ts';
import { NOW } from './fixtures.ts';

const ps = (...statuses: ParticipationStatus[]) => statuses.map((status) => ({ status }));
const ALL: ParticipationStatus[] = ['INVITED', 'REQUESTED', 'PENDING_APPROVAL', 'CONFIRMED', 'MAYBE', 'DECLINED', 'CANCELLED', 'WAITLISTED', 'CHECKED_IN', 'NO_RESPONSE', 'REMOVED'];

describe('computeCapacity', () => {
  it('C1/C4/C10: only CONFIRMED and CHECKED_IN consume places', () => {
    const s = computeCapacity({ capacity: 10, participants: ps(...ALL), holds: [], now: NOW });
    assert.equal(s.confirmed, 2);
    assert.equal(s.available, 8);
    assert.equal(s.maybe, 1);
    assert.equal(s.noResponse, 1);
    assert.equal(s.declined, 1);
    assert.equal(s.waitlisted, 1);
    assert.equal(s.pendingApproval, 2);
  });
  it('C3: unexpired holds count, expired holds do not', () => {
    const holds = [{ expiresAt: '2026-11-24T00:00:00Z' }, { expiresAt: '2026-11-22T00:00:00Z' }];
    const s = computeCapacity({ capacity: 3, participants: ps('CONFIRMED'), holds, now: NOW });
    assert.equal(s.activeHolds, 1);
    assert.equal(s.available, 1);
  });
  it('C8: reduced capacity shows over-capacity, never a negative availability', () => {
    const s = computeCapacity({ capacity: 2, participants: ps('CONFIRMED', 'CONFIRMED', 'CHECKED_IN'), holds: [], now: NOW });
    assert.equal(s.available, 0);
    assert.equal(s.overCapacityBy, 1);
    assert.equal(s.canConfirm, false);
  });
  it('no limit → available null, always can confirm', () => {
    const s = computeCapacity({ capacity: null, participants: ps('CONFIRMED'), holds: [], now: NOW });
    assert.equal(s.available, null);
    assert.equal(s.utilisation, null);
    assert.equal(s.canConfirm, true);
  });
  it('utilisation = confirmed / capacity', () => {
    assert.equal(computeCapacity({ capacity: 4, participants: ps('CONFIRMED'), holds: [], now: NOW }).utilisation, 0.25);
  });
});

describe('decideReservation', () => {
  it('confirms while there is room, waitlists when full', () => {
    assert.equal(decideReservation({ capacity: 10, confirmedCount: 9, activeHolds: 0, existingStatus: null }), 'CONFIRMED');
    assert.equal(decideReservation({ capacity: 10, confirmedCount: 10, activeHolds: 0, existingStatus: null }), 'WAITLISTED');
    assert.equal(decideReservation({ capacity: 10, confirmedCount: 9, activeHolds: 1, existingStatus: null }), 'WAITLISTED');
  });
  it('C5: a second registration by the same person is a no-op', () => {
    for (const s of ['CONFIRMED', 'CHECKED_IN', 'WAITLISTED', 'REQUESTED', 'PENDING_APPROVAL'] as const) {
      assert.equal(decideReservation({ capacity: 10, confirmedCount: 0, activeHolds: 0, existingStatus: s }), 'ALREADY_PARTICIPATING');
    }
  });
  it('R2: accepting an invitation for a full environment waitlists, it does not confirm', () => {
    assert.equal(decideReservation({ capacity: 5, confirmedCount: 5, activeHolds: 0, existingStatus: 'INVITED' }), 'WAITLISTED');
  });
  it('someone who cancelled earlier can register again', () => {
    assert.equal(decideReservation({ capacity: 5, confirmedCount: 1, activeHolds: 0, existingStatus: 'CANCELLED' }), 'CONFIRMED');
  });
  it('C6 model: N sequential decisions never exceed capacity', () => {
    let confirmed = 0;
    let waitlisted = 0;
    for (let i = 0; i < 50; i++) {
      const outcome = decideReservation({ capacity: 10, confirmedCount: confirmed, activeHolds: 0, existingStatus: null });
      if (outcome === 'CONFIRMED') confirmed++;
      else waitlisted++;
    }
    assert.equal(confirmed, 10);
    assert.equal(waitlisted, 40);
  });
});

describe('status transitions', () => {
  it('C10: the system never turns NO_RESPONSE (or anything) into DECLINED', () => {
    for (const from of ALL) assert.equal(canTransition(from, 'DECLINED', 'SYSTEM'), false, from);
  });
  it('R2: no participant or organizer can jump to CONFIRMED; only the reservation step (SYSTEM) can', () => {
    for (const from of ALL) {
      assert.equal(canTransition(from, 'CONFIRMED', 'PARTICIPANT'), false, `participant ${from}`);
      if (from !== 'CHECKED_IN') assert.equal(canTransition(from, 'CONFIRMED', 'ORGANIZER'), false, `organizer ${from}`);
    }
    assert.equal(canTransition('INVITED', 'CONFIRMED', 'SYSTEM'), true);
  });
  it('participants can cancel; check-in staff can only check in', () => {
    assert.equal(canTransition('CONFIRMED', 'CANCELLED', 'PARTICIPANT'), true);
    assert.equal(canTransition('CONFIRMED', 'CHECKED_IN', 'CHECKIN_STAFF'), true);
    assert.equal(canTransition('CONFIRMED', 'REMOVED', 'CHECKIN_STAFF'), false);
    assert.equal(canTransition('CHECKED_IN', 'CHECKED_IN', 'CHECKIN_STAFF'), false); // duplicate scan
  });
  it('C2: cancelling or removing a confirmed person releases a place', () => {
    assert.equal(releasesPlace('CONFIRMED', 'CANCELLED'), true);
    assert.equal(releasesPlace('CONFIRMED', 'REMOVED'), true);
    assert.equal(releasesPlace('CONFIRMED', 'CHECKED_IN'), false);
    assert.equal(releasesPlace('WAITLISTED', 'CANCELLED'), false);
  });
});

describe('waitlist and rates', () => {
  it('promotes the first eligible person by position', () => {
    const next = nextForPromotion([
      { participantId: 'c', position: 3, eligible: true },
      { participantId: 'a', position: 1, eligible: false },
      { participantId: 'b', position: 2, eligible: true },
    ]);
    assert.equal(next?.participantId, 'b');
    assert.equal(nextForPromotion([{ participantId: 'a', position: 1, eligible: false }]), null);
  });
  it('attendance and replacement rates', () => {
    assert.equal(attendanceRate(8, 10), 0.8);
    assert.equal(attendanceRate(0, 0), null);
    assert.equal(replacementRate(3, 4), 0.75);
    assert.equal(replacementRate(5, 4), 1);
    assert.equal(replacementRate(0, 0), null);
  });
});
