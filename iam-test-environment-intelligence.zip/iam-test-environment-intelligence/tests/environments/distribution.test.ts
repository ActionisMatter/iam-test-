import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildPersonCandidates, evaluateTriggers, invitationBudget } from '../../src/server/environments/distribution.ts';
import type { TriggerSnapshot } from '../../src/server/environments/distribution.ts';
import { canInvite } from '../../src/server/environments/invitations.ts';
import type { CanInviteInput } from '../../src/server/environments/invitations.ts';
import { IN_3_DAYS, NOW, distributionPolicy } from './fixtures.ts';

const snap = (o: Partial<TriggerSnapshot> = {}): TriggerSnapshot => ({
  capacity: 40,
  available: 10,
  utilisation: 0.75,
  waitlisted: 0,
  cancellationsSinceLastRun: 0,
  ...o,
});

describe('evaluateTriggers', () => {
  it('never returns a "send" action; the strongest outcome is a proposal', () => {
    const policy = distributionPolicy({
      triggers: [{ type: 'CANCELLATION', minCount: 1 }, { type: 'CAPACITY_INCREASED' }, { type: 'AVAILABLE_BELOW', places: 5 }],
    });
    const fired = evaluateTriggers({
      policy,
      previous: snap({ capacity: 30, available: 8 }),
      current: snap({ available: 5, cancellationsSinceLastRun: 2 }),
      startsAt: IN_3_DAYS,
      now: NOW,
      alreadyFired: [],
    });
    assert.deepEqual(fired.map((f) => f.trigger).sort(), ['AVAILABLE_BELOW', 'CANCELLATION', 'CAPACITY_INCREASED']);
    for (const f of fired) assert.ok(['CREATE_PROPOSAL', 'PROMOTE_WAITLIST', 'NOTIFY_ORGANIZER'].includes(f.action));
  });

  it('waitlist goes first when places open', () => {
    const fired = evaluateTriggers({
      policy: distributionPolicy({ triggers: [{ type: 'WAITLIST_ACTIVATED' }, { type: 'CANCELLATION', minCount: 1 }] }),
      previous: snap({ available: 0 }),
      current: snap({ available: 1, waitlisted: 3, cancellationsSinceLastRun: 1 }),
      startsAt: IN_3_DAYS,
      now: NOW,
      alreadyFired: [],
    });
    assert.deepEqual(fired.map((f) => f.action), ['PROMOTE_WAITLIST', 'PROMOTE_WAITLIST']);
  });

  it('mode NONE or too close to the start → notify the organizer only', () => {
    const base = { previous: null, current: snap({ cancellationsSinceLastRun: 1 }), now: NOW, alreadyFired: [] };
    const none = evaluateTriggers({ ...base, policy: distributionPolicy({ mode: 'NONE', triggers: [{ type: 'CANCELLATION', minCount: 1 }] }), startsAt: IN_3_DAYS });
    assert.equal(none[0]?.action, 'NOTIFY_ORGANIZER');
    const late = evaluateTriggers({ ...base, policy: distributionPolicy({ minHoursBeforeStart: 100, triggers: [{ type: 'CANCELLATION', minCount: 1 }] }), startsAt: IN_3_DAYS });
    assert.equal(late[0]?.action, 'NOTIFY_ORGANIZER');
  });

  it('AVAILABLE_BELOW fires on the crossing only', () => {
    const policy = distributionPolicy({ triggers: [{ type: 'AVAILABLE_BELOW', places: 5 }] });
    const run = (prev: number, cur: number) =>
      evaluateTriggers({ policy, previous: snap({ available: prev }), current: snap({ available: cur }), startsAt: IN_3_DAYS, now: NOW, alreadyFired: [] }).length;
    assert.equal(run(6, 5), 1);
    assert.equal(run(5, 4), 0);
    assert.equal(run(8, 7), 0);
  });

  it('UTILISATION_BELOW fires once inside its check window', () => {
    const policy = distributionPolicy({ triggers: [{ type: 'UTILISATION_BELOW', percent: 60, checkAtHoursBeforeStart: 96 }] });
    const input = { policy, previous: null, current: snap({ utilisation: 0.5 }), startsAt: IN_3_DAYS, now: NOW, alreadyFired: [] as string[] };
    const first = evaluateTriggers(input);
    assert.equal(first.length, 1);
    assert.equal(first[0]?.action, 'CREATE_PROPOSAL');
    assert.equal(evaluateTriggers({ ...input, alreadyFired: [first[0]!.key] }).length, 0);
    assert.equal(evaluateTriggers({ ...input, current: snap({ utilisation: 0.7 }) }).length, 0);
  });
});

const inviteInput = (o: Partial<CanInviteInput> = {}): CanInviteInput => ({
  inviter: 'ORGANIZER',
  kind: 'DISTRIBUTION_SUGGESTION',
  environmentId: 'env-1',
  environmentOrganizationId: 'org-1',
  environmentCategoryCodes: ['technology.artificial_intelligence'],
  recipientProfileContextId: null,
  preferences: [{ profileContextId: null, kind: 'DISTRIBUTION_SUGGESTION', categoryCodes: null, channel: 'IN_APP', allowSuggestToOrganizers: true }],
  suppressions: [],
  hasOpenInvitation: false,
  recipientIsParticipating: false,
  distributionInvitationsLast7Days: 0,
  weeklyDistributionCap: 3,
  ...o,
});

describe('canInvite', () => {
  it('allows an opted-in recipient', () => {
    assert.deepEqual(canInvite(inviteInput()), { allowed: true, channel: 'IN_APP', reason: 'ALLOWED' });
  });
  it('the distribution engine itself can never invite', () => {
    assert.equal(canInvite(inviteInput({ inviter: 'DISTRIBUTION_ENGINE' })).reason, 'ENGINE_CANNOT_INVITE');
  });
  it('distribution suggestions require an explicit opt-in', () => {
    assert.equal(canInvite(inviteInput({ preferences: [] })).reason, 'NOT_OPTED_IN_TO_SUGGESTIONS');
    const off = [{ profileContextId: null, kind: 'DISTRIBUTION_SUGGESTION' as const, categoryCodes: null, channel: 'IN_APP' as const, allowSuggestToOrganizers: false }];
    assert.equal(canInvite(inviteInput({ preferences: off })).reason, 'NOT_OPTED_IN_TO_SUGGESTIONS');
  });
  it('duplicates, participants, suppressions and caps are blocked', () => {
    assert.equal(canInvite(inviteInput({ hasOpenInvitation: true })).reason, 'DUPLICATE_OPEN_INVITATION');
    assert.equal(canInvite(inviteInput({ recipientIsParticipating: true })).reason, 'ALREADY_PARTICIPATING');
    assert.equal(canInvite(inviteInput({ suppressions: [{ scope: 'GLOBAL', scopeId: null }] })).reason, 'SUPPRESSED');
    assert.equal(canInvite(inviteInput({ suppressions: [{ scope: 'ORGANIZATION', scopeId: 'org-1' }] })).reason, 'SUPPRESSED');
    assert.equal(canInvite(inviteInput({ suppressions: [{ scope: 'ORGANIZATION', scopeId: 'org-2' }] })).allowed, true);
    assert.equal(canInvite(inviteInput({ distributionInvitationsLast7Days: 3 })).reason, 'FREQUENCY_CAP');
  });
  it('respects channel NONE and category filters (main category matches sub)', () => {
    const pref = (categoryCodes: string[] | null, channel: 'IN_APP' | 'NONE' = 'IN_APP') => [
      { profileContextId: null, kind: 'DISTRIBUTION_SUGGESTION' as const, categoryCodes, channel, allowSuggestToOrganizers: true },
    ];
    assert.equal(canInvite(inviteInput({ preferences: pref(null, 'NONE') })).reason, 'OPTED_OUT');
    assert.equal(canInvite(inviteInput({ preferences: pref(['creative']) })).reason, 'CATEGORY_NOT_WANTED');
    assert.equal(canInvite(inviteInput({ preferences: pref(['technology']) })).allowed, true);
  });
  it('a context-specific preference beats the global one', () => {
    const prefs = [
      { profileContextId: null, kind: 'PERSONAL' as const, categoryCodes: null, channel: 'EMAIL' as const, allowSuggestToOrganizers: false },
      { profileContextId: 'ctx-social', kind: 'PERSONAL' as const, categoryCodes: null, channel: 'NONE' as const, allowSuggestToOrganizers: false },
    ];
    assert.equal(canInvite(inviteInput({ kind: 'PERSONAL', preferences: prefs, recipientProfileContextId: 'ctx-social' })).reason, 'OPTED_OUT');
    assert.equal(canInvite(inviteInput({ kind: 'PERSONAL', preferences: prefs, recipientProfileContextId: 'ctx-business' })).channel, 'EMAIL');
  });
  it('personal invitations default to in-app; other kinds need a preference', () => {
    assert.deepEqual(canInvite(inviteInput({ kind: 'PERSONAL', preferences: [] })), { allowed: true, channel: 'IN_APP', reason: 'ALLOWED' });
    assert.equal(canInvite(inviteInput({ kind: 'HUB', inviter: 'HUB_ADMIN', preferences: [] })).reason, 'NO_PREFERENCE');
  });
  it('inviters are limited to their kinds; guests are limited per member', () => {
    assert.equal(canInvite(inviteInput({ inviter: 'HUB_ADMIN' })).reason, 'INVITER_NOT_PERMITTED_FOR_KIND');
    const guest = inviteInput({ inviter: 'PARTICIPANT_GUEST', kind: 'PERSONAL', preferences: [], guestsPerMember: 1 });
    assert.equal(canInvite({ ...guest, guestsAlreadyInvited: 0 }).allowed, true);
    assert.equal(canInvite({ ...guest, guestsAlreadyInvited: 1 }).reason, 'GUEST_LIMIT');
  });
});

describe('proposal candidates', () => {
  const allowed = { allowed: true, channel: 'IN_APP' as const, reason: 'ALLOWED' as const };
  const blocked = { allowed: false, channel: 'NONE' as const, reason: 'NOT_OPTED_IN_TO_SUGGESTIONS' as const };
  const a = (level: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE', n = 1) => ({ level, reasons: Array.from({ length: n }, () => ({ kind: 'same_country' as const, countryCode: 'NL' })) });

  it('only eligible, invitable, somewhat relevant people; sorted; nobody pre-selected', () => {
    const list = buildPersonCandidates(
      [
        { id: 'low', assessment: a('LOW'), eligible: true, invite: allowed },
        { id: 'high', assessment: a('HIGH'), eligible: true, invite: allowed },
        { id: 'not-opted-in', assessment: a('HIGH', 3), eligible: true, invite: blocked },
        { id: 'ineligible', assessment: a('HIGH'), eligible: false, invite: allowed },
        { id: 'irrelevant', assessment: a('NONE', 0), eligible: true, invite: allowed },
        { id: 'medium', assessment: a('MEDIUM'), eligible: true, invite: allowed },
      ],
      10,
    );
    assert.deepEqual(list.map((c) => c.id), ['high', 'medium', 'low']);
    assert.ok(list.every((c) => c.selected === false));
  });
  it('invitation budget is capped by the policy and by 3× the open places', () => {
    assert.equal(invitationBudget(distributionPolicy({ maxInvitationsPerRun: 25 }), 4), 12);
    assert.equal(invitationBudget(distributionPolicy({ maxInvitationsPerRun: 25 }), 20), 25);
    assert.equal(invitationBudget(distributionPolicy(), 0), 0);
  });
});
