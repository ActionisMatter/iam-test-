import type {
  AccessPolicy,
  ActorContext,
  DistributionPolicy,
  EnvironmentAudienceProfile,
  EnvironmentForPolicy,
  ProfileContext,
} from '../../src/domain/environments/types.ts';

export const NOW = new Date('2026-11-23T12:00:00Z');
export const IN_3_DAYS = '2026-11-26T19:00:00Z';
export const YESTERDAY = '2026-11-22T19:00:00Z';

export function policy(overrides: Partial<AccessPolicy> = {}): AccessPolicy {
  return {
    version: 1,
    accessModel: 'PUBLIC',
    discoverable: true,
    registrationMode: 'OPEN',
    approvalMode: 'AUTO_WITHIN_CONDITIONS',
    autoConditions: [],
    eligibilityRules: [],
    guestPolicy: 'NONE',
    guestsPerMember: null,
    communityHubIds: [],
    crossCommunity: 'NONE',
    allowedPartnerHubIds: [],
    ...overrides,
  };
}

export function env(policyOverrides: Partial<AccessPolicy> = {}, overrides: Partial<EnvironmentForPolicy> = {}): EnvironmentForPolicy {
  return { id: 'env-1', kind: 'EVENT', status: 'PUBLISHED', startsAt: IN_3_DAYS, policy: policy(policyOverrides), ...overrides };
}

export function actor(overrides: Partial<ActorContext> = {}): ActorContext {
  return {
    userId: 'user-1',
    isPlatformAdmin: false,
    isOwningOrgAdmin: false,
    organizerRole: null,
    participationStatus: null,
    hasOpenInvitation: false,
    hubIds: [],
    isNominatedGuest: false,
    ...overrides,
  };
}

export const anonymous = (): ActorContext => actor({ userId: null });

export function profile(overrides: Partial<ProfileContext> = {}): ProfileContext {
  return {
    userId: 'user-1',
    profileContextId: null,
    audienceCodes: [],
    interestCodes: [],
    purposeCodes: [],
    skills: [],
    countryCode: 'NL',
    city: 'Amersfoort',
    hubIds: [],
    organizationIds: [],
    completedEnvironmentIds: [],
    birthYear: null,
    ...overrides,
  };
}

export function audienceProfile(overrides: Partial<EnvironmentAudienceProfile> = {}): EnvironmentAudienceProfile {
  return {
    categoryCodes: [],
    audienceCodes: [],
    purposeCodes: [],
    targetSkillIds: [],
    communityHubIds: [],
    locationScope: 'scope.local',
    city: 'Amersfoort',
    countryCode: 'NL',
    ...overrides,
  };
}

export function distributionPolicy(overrides: Partial<DistributionPolicy> = {}): DistributionPolicy {
  return {
    version: 1,
    mode: 'SUGGEST_ALL',
    approvalMethod: 'PERSONAL_INVITATION_ONLY',
    triggers: [],
    maxInvitationsPerRun: 25,
    minHoursBeforeStart: 24,
    ...overrides,
  };
}
