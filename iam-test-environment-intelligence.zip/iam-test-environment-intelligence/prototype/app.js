/**
 * Environment Intelligence prototype — UI over the real engine.
 * Every decision shown on screen (access, eligibility, approval, capacity,
 * relevance, invitation permission, triggers, candidates) is computed by
 * src/server/environments/*.ts, loaded through ts-loader.js. Data is sample
 * data from data.js and lives only in this page (no backend, no persistence).
 */
import { loadEngine } from './ts-loader.js';
import { HUBS, SKILLS, PERSONAS, NOMINATED_GUESTS, buildEnvironments, buildParticipants, buildCandidatePool, label } from './data.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

let E;
try {
  E = await loadEngine();
} catch (err) {
  $('#app').innerHTML = `<div class="card fatal"><div class="eyebrow">Engine failed to load</div><p>${esc(err.message)}</p></div>`;
  throw err;
}
const { policy: P, eligibility: EL, relevance: RV, capacity: CP, invitations: IV, distribution: DS } = E;

const NOW = new Date();
const envs = buildEnvironments(NOW);
const parts = buildParticipants();
const pool = buildCandidatePool();
const state = {
  persona: 'sanne',
  envId: 'env-lab',
  view: 'participant',
  trace: null,
  statusFilter: 'ALL',
  cancellations: Object.fromEntries(envs.map((e) => [e.id, 0])),
  fired: Object.fromEntries(envs.map((e) => [e.id, []])),
  log: Object.fromEntries(envs.map((e) => [e.id, []])),
  proposal: {},
  selected: new Set(),
  queued: Object.fromEntries(envs.map((e) => [e.id, []])),
};
let promoSeq = 0;

// ---------------------------------------------------------------- helpers
const persona = () => PERSONAS.find((p) => p.id === state.persona);
const env = () => envs.find((e) => e.id === state.envId);
const forPolicy = (e) => ({ id: e.id, kind: e.kind, status: e.status, startsAt: e.startsAt, policy: e.policy });
const myPart = (e, per = persona()) => (per.profile ? parts[e.id].find((x) => x.userId === per.profile.userId) : null);

function actorFor(e, per = persona()) {
  const base = { userId: null, isPlatformAdmin: false, isOwningOrgAdmin: false, organizerRole: null, participationStatus: null, hasOpenInvitation: false, hubIds: [], isNominatedGuest: false };
  if (per.anonymous) return base;
  if (per.organizer) return { ...base, userId: 'u-org', organizerRole: 'OWNER' };
  const mine = myPart(e, per);
  return {
    ...base,
    userId: per.profile.userId,
    participationStatus: mine ? mine.status : null,
    hubIds: per.profile.hubIds,
    isNominatedGuest: (NOMINATED_GUESTS[e.id] || []).includes(per.profile.userId),
  };
}

const snapshot = (e) => CP.computeCapacity({ capacity: e.capacity, participants: parts[e.id], holds: [], now: NOW });
const trig = (e, s) => ({ capacity: s.capacity, available: s.available, utilisation: s.utilisation, waitlisted: s.waitlisted, cancellationsSinceLastRun: state.cancellations[e.id] });

const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Ongoing');
const pct = (x) => (x === null || x === undefined ? '—' : `${Math.round(x * 100)}%`);
const log = (e, text) => state.log[e.id].unshift({ t: new Date(), text });

const ACCESS_TEXT = {
  ORGANIZER: 'You organise this environment.', STAFF: 'You are check-in staff.', PARTICIPANT: 'You already take part.',
  INVITED: 'You have a personal invitation.', OPEN_REGISTRATION: 'Open registration.', REQUEST_REQUIRED: 'Participation by request.',
  COMMUNITY_MEMBER: 'You are a member of this community.', NOMINATED_GUEST: 'A member nominated you as their guest.',
  PARTNER_HUB_MEMBER: 'Your hub is an allowed partner hub.', SIGN_IN_REQUIRED: 'Sign in to take part.',
  INVITATION_REQUIRED: 'By personal invitation only.', MEMBERS_ONLY: 'For community members only.',
  REGISTRATION_CLOSED: 'Registration has closed.', NOT_PUBLISHED: 'Not published.', NOT_FOUND: 'Not visible to you (404).',
};
const MODEL_TEXT = { PUBLIC: 'Public', PRIVATE: 'Private', CURATED: 'Curated', COMMUNITY: 'Community' };
const INVITE_TEXT = {
  ENGINE_CANNOT_INVITE: 'engine cannot invite', NOT_OPTED_IN_TO_SUGGESTIONS: 'not opted in to suggestions', OPTED_OUT: 'opted out (channel off)',
  CATEGORY_NOT_WANTED: 'does not want this category', FREQUENCY_CAP: 'weekly cap reached', DUPLICATE_OPEN_INVITATION: 'already invited',
  ALREADY_PARTICIPATING: 'already taking part', SUPPRESSED: 'unsubscribed', NO_PREFERENCE: 'no preference set', GUEST_LIMIT: 'guest limit reached',
  INVITER_NOT_PERMITTED_FOR_KIND: 'inviter not permitted',
};

function reasonText(r) {
  switch (r.kind) {
    case 'shared_interest': return `shares interest: ${r.codes.map(label).join(', ')}`;
    case 'related_interest': return `related interest: ${r.codes.map(label).join(', ')}`;
    case 'audience_match': return `profile type: ${r.codes.map(label).join(', ')}`;
    case 'purpose_match': return `goal: ${r.codes.map(label).join(', ')}`;
    case 'skill_match': return `skill: ${r.skillIds.map((s) => SKILLS[s] || s).join(', ')}`;
    case 'hub_member': return `member of ${r.hubIds.map((h) => HUBS[h] || h).join(', ')}`;
    case 'same_city': return `lives in ${r.city}`;
    case 'same_country': return 'same country';
    default: return r.kind;
  }
}

const pill = (status) => `<span class="st st-${status}">${status.replace('_', ' ')}</span>`;

// ---------------------------------------------------------------- the six-question chain
function runChain(e, mode) {
  const per = persona();
  const actor = actorFor(e, per);
  const prof = per.profile;
  const rows = [];
  const relevance = RV.assessRelevance(prof, e.audience);
  rows.push({ q: 1, name: 'Audience relevance', ok: null, text: `${relevance.level}${relevance.reasons.length ? ' · ' + relevance.reasons.map(reasonText).join('; ') : ''}`, note: 'Shown for information. Never decides (R1).' });

  const access = P.checkAccess(actor, forPolicy(e), NOW);
  rows.push({ q: 3, name: 'Access permission', ok: ['REGISTER', 'REQUEST', 'RESPOND_TO_INVITATION'].includes(access.action) || access.action === 'OWN_PARTICIPATION', text: `${access.action} · ${ACCESS_TEXT[access.reason] || access.reason}` });
  if (!rows.at(-1).ok) return finish(rows, 'Stopped at access.');

  const elig = EL.checkEligibility(prof, e.policy.eligibilityRules, NOW);
  rows.push({ q: 2, name: 'Eligibility', ok: elig.eligible, text: elig.eligible ? (e.policy.eligibilityRules.length ? 'All requirements met.' : 'No requirements set.') : elig.unmet.map((u) => u.message).join(' ') });
  if (!elig.eligible) return finish(rows, 'Stopped at eligibility.');

  const isAccept = mode === 'accept';
  const path = isAccept ? 'PERSONAL_INVITATION_ACCEPTANCE'
    : mode === 'confirm-maybe' ? 'SELF_REGISTRATION'
    : access.reason === 'NOMINATED_GUEST' ? 'GUEST'
    : access.reason === 'PARTNER_HUB_MEMBER' ? 'CROSS_COMMUNITY'
    : access.action === 'REQUEST' ? 'REQUEST' : 'SELF_REGISTRATION';
  rows.push({ q: 5, name: 'Invitation', ok: null, text: isAccept ? 'Accepting a personal invitation. The invitation itself does not confirm anything (R2).' : 'Not an invitation: self-service path.' });

  const approval = P.approvalRequirement(forPolicy(e), path, { hubIds: prof.hubIds, audienceCodes: prof.audienceCodes }, NOW, e.distribution.approvalMethod === 'MANUAL_APPROVAL');
  const approvalText = approval.required === 'NONE' ? 'No approval needed.' : approval.required === 'ORGANIZER'
    ? `Organizer approval needed${approval.unmetConditions.length ? ` (auto conditions not met: ${approval.unmetConditions.join(', ')})` : ''}.`
    : 'Only possible with a personal invitation.';
  rows.push({ q: 6, name: 'Approval', ok: approval.required !== 'INVITATION', text: `${approval.required} · ${approvalText}`, path });
  if (approval.required === 'INVITATION') return finish(rows, 'Stopped: invitation required.');

  let mine = myPart(e, per);
  if (approval.required === 'ORGANIZER') {
    if (!mine) { mine = { id: `${e.id}-${prof.userId}`, userId: prof.userId, name: per.name, status: 'PENDING_APPROVAL', source: 'SELF', position: null }; parts[e.id].push(mine); }
    else mine.status = 'PENDING_APPROVAL';
    rows.push({ q: 4, name: 'Capacity', ok: null, text: 'Not checked yet: capacity is decided when the organizer approves.' });
    log(e, `${per.name} requested to join → PENDING_APPROVAL`);
    return finish(rows, 'Request sent to the organizer.', 'PENDING_APPROVAL');
  }

  const s = snapshot(e);
  const existing = mine ? mine.status : null;
  const outcome = CP.decideReservation({ capacity: e.capacity, confirmedCount: s.confirmed, activeHolds: s.activeHolds, existingStatus: existing });
  rows.push({ q: 4, name: 'Capacity', ok: outcome !== 'ALREADY_PARTICIPATING', text: `${outcome} · ${s.available === null ? 'no limit' : `${s.available} of ${s.capacity} places free`}` });
  if (outcome === 'ALREADY_PARTICIPATING') return finish(rows, 'You already take part.');
  if (mine && existing && !CP.canTransition(existing, outcome, 'SYSTEM')) return finish(rows, `Transition ${existing} → ${outcome} is not allowed.`);
  if (!mine) { mine = { id: `${e.id}-${prof.userId}`, userId: prof.userId, name: per.name, status: outcome, source: 'SELF', position: null }; parts[e.id].push(mine); }
  else { mine.status = outcome; if (isAccept) mine.source = mine.source === 'DISTRIBUTION' ? 'DISTRIBUTION' : 'INVITATION'; }
  if (outcome === 'WAITLISTED') mine.position = Math.max(0, ...parts[e.id].map((p) => p.position || 0)) + 1;
  log(e, `${per.name} → ${outcome}`);
  return finish(rows, outcome === 'CONFIRMED' ? 'Confirmed. Your access pass is in My passes.' : 'The environment is full: you are on the waitlist.', outcome);
}

function finish(rows, summary, result = null) {
  rows.sort((a, b) => a.q - b.q);
  state.trace = { envId: state.envId, persona: state.persona, rows, summary, result };
  render();
}

// ---------------------------------------------------------------- capacity changes + triggers
function cancel(e, part, by) {
  const before = snapshot(e);
  if (!CP.canTransition(part.status, 'CANCELLED', 'PARTICIPANT') && by === 'PARTICIPANT') return;
  const freed = CP.releasesPlace(part.status, 'CANCELLED');
  part.status = 'CANCELLED';
  part.position = null;
  if (freed) state.cancellations[e.id]++;
  log(e, `${part.name} cancelled${freed ? ' · place released' : ''}`);
  if (freed && e.waitlistMode === 'AUTO_PROMOTE') promote(e);
  afterCapacityChange(e, before);
}

function promote(e) {
  const waiting = parts[e.id].filter((p) => p.status === 'WAITLISTED').map((p) => ({ participantId: p.id, position: p.position || 0, eligible: true }));
  const next = CP.nextForPromotion(waiting);
  if (!next) return;
  const s = snapshot(e);
  const p = parts[e.id].find((x) => x.id === next.participantId);
  if (CP.decideReservation({ capacity: e.capacity, confirmedCount: s.confirmed, activeHolds: 0, existingStatus: null }) === 'CONFIRMED' && CP.canTransition('WAITLISTED', 'CONFIRMED', 'SYSTEM')) {
    p.status = 'CONFIRMED'; p.position = null; p.source = 'WAITLIST_PROMOTION'; promoSeq++;
    log(e, `Waitlist: ${p.name} promoted to CONFIRMED (auto-promote)`);
  }
}

function afterCapacityChange(e, before) {
  const after = snapshot(e);
  const firings = DS.evaluateTriggers({ policy: e.distribution, previous: trig(e, before), current: trig(e, after), startsAt: e.startsAt, now: NOW, alreadyFired: state.fired[e.id] });
  for (const f of firings) {
    state.fired[e.id].push(f.key);
    log(e, `Trigger ${f.trigger} → ${f.action}: ${f.note}`);
    if (f.action === 'CREATE_PROPOSAL' && !state.proposal[e.id]) {
      state.proposal[e.id] = { trigger: f.trigger, createdAt: new Date() };
      state.cancellations[e.id] = 0;
    }
  }
  render();
}

function setCapacity(e, delta) {
  if (e.capacity === null) return;
  const before = snapshot(e);
  e.capacity = Math.max(1, e.capacity + delta);
  log(e, `Capacity set to ${e.capacity}`);
  afterCapacityChange(e, before);
}

// ---------------------------------------------------------------- distribution proposal
function buildProposal(e) {
  const personaPool = PERSONAS.filter((p) => p.profile).map((p) => ({
    id: p.profile.userId, name: p.name, allowSuggest: p.allowSuggest, profile: p.profile,
    preferences: [{ profileContextId: null, kind: 'DISTRIBUTION_SUGGESTION', categoryCodes: null, channel: 'IN_APP', allowSuggestToOrganizers: p.allowSuggest }],
  }));
  const people = [...pool, ...personaPool];
  const ACTIVE = new Set(['CONFIRMED', 'CHECKED_IN', 'WAITLISTED', 'REQUESTED', 'PENDING_APPROVAL', 'INVITED', 'MAYBE']);
  const rows = people.map((c) => {
    const existing = parts[e.id].find((x) => x.userId === c.id);
    const assessment = RV.assessRelevance(c.profile, e.audience);
    const elig = EL.checkEligibility(c.profile, e.policy.eligibilityRules, NOW);
    const invite = IV.canInvite({
      inviter: 'ORGANIZER', kind: 'DISTRIBUTION_SUGGESTION', environmentId: e.id, environmentOrganizationId: 'org-am',
      environmentCategoryCodes: e.categories, recipientProfileContextId: null, preferences: c.preferences, suppressions: [],
      hasOpenInvitation: existing ? existing.status === 'INVITED' : false, recipientIsParticipating: existing ? ACTIVE.has(existing.status) : false,
      distributionInvitationsLast7Days: 0, weeklyDistributionCap: 3,
    });
    return { c, existing, input: { id: c.id, assessment, eligible: elig.eligible, invite } };
  });
  const s = snapshot(e);
  const budget = DS.invitationBudget(e.distribution, s.available);
  const candidates = DS.buildPersonCandidates(rows.map((r) => r.input), budget);
  const excluded = {};
  for (const r of rows) {
    if (candidates.some((c) => c.id === r.c.id)) continue;
    const why = !r.input.invite.allowed ? INVITE_TEXT[r.input.invite.reason] || r.input.invite.reason
      : !r.input.eligible ? 'does not meet requirements'
      : r.input.assessment.level === 'NONE' ? 'no relevance' : 'over the invitation budget';
    excluded[why] = (excluded[why] || 0) + 1;
  }
  const names = Object.fromEntries(people.map((p) => [p.id, p.name]));
  const hubGroups = ['SUGGEST_HUBS', 'SUGGEST_ALL'].includes(e.distribution.mode)
    ? Object.entries(HUBS).filter(([id]) => !e.policy.communityHubIds.includes(id)).map(([id, n]) => ({ id, name: n, members: people.filter((p) => p.profile.hubIds.includes(id)).length }))
    : [];
  return { candidates, excluded, budget, names, hubGroups };
}

function approveRun(e, prop) {
  const chosen = prop.candidates.filter((c) => state.selected.has(c.id));
  for (const c of chosen) {
    parts[e.id].push({ id: `${e.id}-${c.id}`, userId: c.id, name: prop.names[c.id], status: 'INVITED', source: 'DISTRIBUTION', position: null });
    state.queued[e.id].push({ name: prop.names[c.id], status: 'APPROVED → QUEUED' });
  }
  log(e, `Distribution run approved: ${chosen.length} invitation(s) queued. Not sent: notifications are not built yet.`);
  delete state.proposal[e.id];
  state.selected.clear();
  render();
}

// ---------------------------------------------------------------- rendering
function render() {
  const per = persona();
  if (per.organizer && state.view === 'participant') state.view = 'organizer';
  if (!per.organizer && state.view === 'organizer') state.view = 'participant';

  $('#personas').innerHTML = PERSONAS.map((p) => `<button data-act="persona" data-id="${p.id}" aria-pressed="${p.id === state.persona}"><b>${esc(p.name)}</b><span>${esc(p.note)}</span></button>`).join('');

  const visible = envs.map((e) => ({ e, a: P.checkAccess(actorFor(e), forPolicy(e), NOW) })).filter((x) => x.a.visible);
  if (!visible.some((x) => x.e.id === state.envId)) state.envId = visible[0]?.e.id;
  const hiddenCount = envs.length - visible.length;

  $('#list').innerHTML = visible.map(({ e, a }) => {
    const mine = myPart(e);
    const s = snapshot(e);
    return `<button class="env ${e.id === state.envId ? 'on' : ''}" data-act="env" data-id="${e.id}">
      <span class="eyebrow">${esc(label(e.format))} · ${esc(MODEL_TEXT[e.policy.accessModel])}</span>
      <span class="t">${esc(e.title)}</span>
      <span class="s">${esc(fmtDate(e.startsAt))} · ${s.capacity === null ? `${s.confirmed} members` : `${s.confirmed}/${s.capacity}`}</span>
      ${mine && mine.status !== 'CANCELLED' ? pill(mine.status) : ''}
    </button>`;
  }).join('') + (hiddenCount ? `<p class="hint">${hiddenCount} environment${hiddenCount > 1 ? 's are' : ' is'} hidden for this viewer: the engine answers 404 instead of revealing ${hiddenCount > 1 ? 'they exist' : 'it exists'}.</p>` : '');

  const e = env();
  if (!e) { $('#detail').innerHTML = '<p class="hint">Nothing visible.</p>'; return; }
  $('#detail').innerHTML = header(e) + (state.view === 'organizer' ? organizerView(e) : participantView(e));
}

function header(e) {
  const s = snapshot(e);
  return `<section class="head card">
    <div class="eyebrow">${esc(e.kind)} · ${esc(label(e.format))} · ${esc(e.venue)}</div>
    <h1>${esc(e.title)}</h1>
    <div class="meta"><span class="model m-${e.policy.accessModel}">${esc(MODEL_TEXT[e.policy.accessModel])}</span>
      <span>${esc(fmtDate(e.startsAt))}</span>
      <span>${s.capacity === null ? `${s.confirmed} members` : `${s.confirmed} of ${s.capacity} places taken · ${s.available} free`}${s.waitlisted ? ` · ${s.waitlisted} waiting` : ''}</span></div>
    <div class="chips">${e.categories.map((c) => `<span class="chip">${esc(label(c))}</span>`).join('')}${e.audience.audienceCodes.map((c) => `<span class="chip dim">${esc(label(c))}</span>`).join('')}</div>
    <p class="blurb">${esc(e.blurb)}</p>
  </section>`;
}

function participantView(e) {
  const per = persona();
  const a = P.checkAccess(actorFor(e), forPolicy(e), NOW);
  const mine = myPart(e);
  let actions = '';
  if (a.action === 'REGISTER') actions = `<button class="btn primary" data-act="join">Register</button>`;
  else if (a.action === 'REQUEST') actions = `<button class="btn primary" data-act="join">Request to join</button>`;
  else if (a.action === 'RESPOND_TO_INVITATION') actions = `<button class="btn primary" data-act="accept">Accept invitation</button><button class="btn" data-act="maybe">Maybe</button><button class="btn" data-act="decline">Decline</button>`;
  else if (a.action === 'OWN_PARTICIPATION' && mine) {
    if (mine.status === 'CONFIRMED') actions = `<button class="btn" data-act="cancel-mine">Cancel my place</button>`;
    else if (mine.status === 'WAITLISTED') actions = `<button class="btn" data-act="cancel-mine">Leave the waitlist</button>`;
    else if (mine.status === 'MAYBE') actions = `<button class="btn primary" data-act="confirm-maybe">Confirm</button><button class="btn" data-act="decline">Decline</button>`;
    else if (['PENDING_APPROVAL', 'REQUESTED'].includes(mine.status)) actions = `<button class="btn" data-act="cancel-mine">Withdraw request</button>`;
  }
  const t = state.trace && state.trace.envId === e.id && state.trace.persona === state.persona ? state.trace : null;
  const relevance = per.profile ? RV.assessRelevance(per.profile, e.audience) : null;
  const pass = mine && (mine.status === 'CONFIRMED' || mine.status === 'CHECKED_IN');
  return `<div class="cols">
    <section class="card pad">
      <div class="eyebrow">Your status</div>
      <div class="you">${mine ? pill(mine.status) : '<span class="st">NOT TAKING PART</span>'} <span class="why">${esc(ACCESS_TEXT[a.reason] || a.reason)}</span></div>
      ${mine && mine.status === 'WAITLISTED' ? `<p class="hint">Position ${mine.position} on the waitlist.</p>` : ''}
      <div class="actions">${actions || '<span class="hint">No action available.</span>'}</div>
      ${t ? traceHTML(t) : '<p class="hint">Take an action to see how the engine decides, question by question.</p>'}
    </section>
    <aside class="side">
      ${pass ? `<section class="card pad pass"><div class="eyebrow">My pass</div><div class="qr" aria-hidden="true">${qrSvg(mine.id)}</div><p class="hint">Opaque, per-participation token. Your personal identity QR is never accepted at the door.</p></section>` : ''}
      ${per.profile ? `<section class="card pad">
        <div class="eyebrow">Why this may suit you</div>
        <p class="rel">${relevance.level}</p>
        <ul class="reasons">${relevance.reasons.map((r) => `<li>${esc(reasonText(r))}</li>`).join('') || '<li class="hint">No overlap with your declared profile.</li>'}</ul>
        <p class="hint">Relevance only orders suggestions. It never lets you in or keeps you out.</p>
      </section>
      <section class="card pad">
        <div class="eyebrow">My invitation preferences</div>
        <label class="tog"><input type="checkbox" data-act="allow" ${per.allowSuggest ? 'checked' : ''}> Organizers may suggest me for environments</label>
        <p class="hint">Off by default. When off, you never appear in a “Fill available spots” proposal.</p>
      </section>` : '<section class="card pad"><p class="hint">Visitors can browse public environments. Sign in to take part.</p></section>'}
    </aside>
  </div>`;
}

function traceHTML(t) {
  return `<div class="trace"><div class="eyebrow">How the engine decided</div>
    <ol>${t.rows.map((r) => `<li class="${r.ok === true ? 'yes' : r.ok === false ? 'no' : 'na'}"><span class="q">Q${r.q}</span><span class="n">${esc(r.name)}</span><span class="r">${esc(r.text)}${r.note ? `<em>${esc(r.note)}</em>` : ''}</span></li>`).join('')}</ol>
    <p class="sum">${esc(t.summary)}</p></div>`;
}

function organizerView(e) {
  const s = snapshot(e);
  const filter = state.statusFilter;
  const rows = parts[e.id].filter((p) => filter === 'ALL' || p.status === filter);
  const stat = (k, v, cls = '') => `<div class="stat ${cls}"><span class="eyebrow">${k}</span><b>${v}</b></div>`;
  const prop = state.proposal[e.id] ? buildProposal(e) : null;
  const statuses = ['ALL', 'CONFIRMED', 'WAITLISTED', 'PENDING_APPROVAL', 'REQUESTED', 'INVITED', 'MAYBE', 'NO_RESPONSE', 'CHECKED_IN', 'DECLINED', 'CANCELLED', 'REMOVED'];
  return `
  <section class="stats">
    ${stat('Capacity', s.capacity ?? '∞')}${stat('Confirmed', s.confirmed, 'ok')}${stat('Available', s.available ?? '∞')}${stat('Waitlist', s.waitlisted, s.waitlisted ? 'warn' : '')}
    ${stat('Maybe', s.maybe)}${stat('Invited', s.invited)}${stat('No response', s.noResponse)}${stat('Pending', s.pendingApproval, s.pendingApproval ? 'warn' : '')}
    ${stat('Checked in', s.checkedIn)}${stat('Utilisation', pct(s.utilisation))}${s.overCapacityBy ? stat('Over capacity', s.overCapacityBy, 'bad') : ''}
  </section>
  <div class="cols">
    <section class="card pad">
      <div class="row-h"><div class="eyebrow">Participants · ${rows.length}</div>
        <select data-act="filter" aria-label="Filter by status">${statuses.map((x) => `<option ${x === filter ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
      <div class="table"><table><thead><tr><th>Name</th><th>Status</th><th>Source</th><th></th></tr></thead><tbody>
      ${rows.map((p) => `<tr><td>${esc(p.name)}</td><td>${pill(p.status)}${p.position ? ` <span class="hint">#${p.position}</span>` : ''}</td><td class="src">${esc(p.source)}</td><td class="ra">${rowActions(p)}</td></tr>`).join('')}
      </tbody></table></div>
      <p class="hint">Organizer actions come from <code>canTransition</code>. Nobody can be set to CONFIRMED by hand: approval runs the capacity check.</p>
    </section>
    <aside class="side">
      <section class="card pad">
        <div class="eyebrow">Simulate</div>
        <div class="actions wrap">
          <button class="btn" data-act="sim-cancel" ${s.confirmed ? '' : 'disabled'}>A participant cancels</button>
          ${e.capacity !== null ? `<button class="btn" data-act="cap" data-d="5">Capacity +5</button><button class="btn" data-act="cap" data-d="-5">Capacity −5</button>` : ''}
          <button class="btn" data-act="fill" ${e.distribution.mode === 'NONE' ? 'disabled' : ''}>Fill available spots</button>
        </div>
        <p class="hint">Waitlist: ${esc(e.waitlistMode.replace('_', ' ').toLowerCase())}. Triggers: ${e.distribution.triggers.map((t) => t.type.replace(/_/g, ' ').toLowerCase()).join(', ') || 'none'}.</p>
      </section>
      ${prop ? proposalHTML(e, prop) : ''}
      ${state.queued[e.id].length ? `<section class="card pad"><div class="eyebrow">Invitation queue · ${state.queued[e.id].length}</div><p class="hint warnline">Sending is off. The Notifications module (EI-P3) does not exist yet, so approved invitations wait in the queue.</p></section>` : ''}
      <section class="card pad">
        <div class="eyebrow">Access policy · v${e.policy.version}</div>
        ${sel('accessModel', 'Access model', ['PUBLIC', 'PRIVATE', 'CURATED', 'COMMUNITY'], e.policy.accessModel)}
        ${sel('registrationMode', 'Registration', ['OPEN', 'REQUEST', 'INVITE_ONLY'], e.policy.registrationMode)}
        ${sel('approvalMode', 'Approval', ['AUTO_WITHIN_CONDITIONS', 'MANUAL', 'INVITATION_ONLY'], e.policy.approvalMode)}
        <label class="tog"><input type="checkbox" data-act="pol-disc" ${e.policy.discoverable ? 'checked' : ''}> Discoverable</label>
        <div class="eyebrow sp">Distribution</div>
        ${sel('mode', 'Mode', ['NONE', 'SUGGEST_INTERESTED', 'SUGGEST_HUBS', 'SUGGEST_ORGANIZATIONS', 'SUGGEST_ALL'], e.distribution.mode, 'dist')}
        ${sel('approvalMethod', 'After acceptance', ['PERSONAL_INVITATION_ONLY', 'MANUAL_APPROVAL', 'AUTO_REGISTER_WITHIN_CONDITIONS'], e.distribution.approvalMethod, 'dist')}
        <p class="hint">Switch persona at the top to see what the change does for them.</p>
      </section>
      <section class="card pad"><div class="eyebrow">Activity</div>
        <ul class="log">${state.log[e.id].slice(0, 12).map((l) => `<li><span>${l.t.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>${esc(l.text)}</li>`).join('') || '<li class="hint">Nothing yet.</li>'}</ul>
      </section>
    </aside>
  </div>`;
}

const sel = (key, lbl, opts, val, scope = 'pol') => `<label class="field"><span>${lbl}</span><select data-act="${scope}" data-key="${key}">${opts.map((o) => `<option ${o === val ? 'selected' : ''}>${o}</option>`).join('')}</select></label>`;

function rowActions(p) {
  const b = [];
  if (['PENDING_APPROVAL', 'REQUESTED'].includes(p.status)) b.push(`<button data-act="approve" data-id="${p.id}">Approve</button>`);
  if (CP.canTransition(p.status, 'DECLINED', 'ORGANIZER')) b.push(`<button data-act="row" data-to="DECLINED" data-id="${p.id}">Decline</button>`);
  if (CP.canTransition(p.status, 'CHECKED_IN', 'ORGANIZER')) b.push(`<button data-act="row" data-to="CHECKED_IN" data-id="${p.id}">Check in</button>`);
  if (CP.canTransition(p.status, 'REMOVED', 'ORGANIZER')) b.push(`<button data-act="row" data-to="REMOVED" data-id="${p.id}">Remove</button>`);
  return b.join('');
}

function proposalHTML(e, prop) {
  const p = state.proposal[e.id];
  return `<section class="card pad proposal">
    <div class="eyebrow">Distribution proposal · ${esc(p.trigger.replace(/_/g, ' ').toLowerCase())}</div>
    <p class="hint">Nothing has been sent. Select people, then approve. Budget for this run: ${prop.budget} invitation${prop.budget === 1 ? '' : 's'}.</p>
    <ul class="cands">${prop.candidates.map((c) => `<li><label><input type="checkbox" data-act="pick" data-id="${c.id}" ${state.selected.has(c.id) ? 'checked' : ''}>
      <span><b>${esc(prop.names[c.id])}</b> <span class="lvl l-${c.assessment.level}">${c.assessment.level}</span><br><span class="hint">${esc(c.assessment.reasons.map(reasonText).join('; '))}</span></span></label></li>`).join('') || '<li class="hint">No eligible, opted-in, relevant people right now.</li>'}</ul>
    ${prop.hubGroups.length ? `<div class="eyebrow sp">Hubs</div><ul class="cands">${prop.hubGroups.map((h) => `<li><span><b>${esc(h.name)}</b><br><span class="hint">${h.members} member${h.members === 1 ? '' : 's'} in the pool · reached only after the hub admin accepts</span></span></li>`).join('')}</ul>` : ''}
    <div class="eyebrow sp">Left out (counts only)</div>
    <ul class="excl">${Object.entries(prop.excluded).map(([k, v]) => `<li>${v} × ${esc(k)}</li>`).join('') || '<li class="hint">Nobody.</li>'}</ul>
    <div class="actions"><button class="btn primary" data-act="approve-run" ${state.selected.size ? '' : 'disabled'}>Approve run (${state.selected.size})</button><button class="btn" data-act="dismiss">Dismiss</button></div>
  </section>`;
}

function qrSvg(seed) {
  let h = 2166136261;
  for (const ch of seed) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  const n = 21, cells = [];
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    const finder = (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7);
    let on;
    if (finder) { const cx = x < 7 ? x : x - (n - 7), cy = y < 7 ? y : y - (n - 7); on = cx === 0 || cy === 0 || cx === 6 || cy === 6 || (cx >= 2 && cx <= 4 && cy >= 2 && cy <= 4); }
    else { h = Math.imul(h ^ (x * 31 + y), 2246822519) >>> 0; on = (h & 7) < 3; }
    if (on) cells.push(`<rect x="${x}" y="${y}" width="1" height="1"/>`);
  }
  return `<svg viewBox="-1 -1 ${n + 2} ${n + 2}"><rect x="-1" y="-1" width="${n + 2}" height="${n + 2}" fill="#f5f5f5"/><g fill="#05070a">${cells.join('')}</g></svg>`;
}

// ---------------------------------------------------------------- events
document.addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-act]');
  if (!b || b.tagName === 'SELECT' || b.type === 'checkbox') return;
  const e = env();
  const act = b.dataset.act;
  if (act === 'persona') { state.persona = b.dataset.id; state.trace = null; render(); return; }
  if (act === 'env') { state.envId = b.dataset.id; state.trace = null; state.selected.clear(); render(); return; }
  if (act === 'join') return runChain(e, 'join');
  if (act === 'accept') return runChain(e, 'accept');
  if (act === 'confirm-maybe') return runChain(e, 'confirm-maybe');
  if (act === 'maybe' || act === 'decline') {
    const mine = myPart(e);
    const to = act === 'maybe' ? 'MAYBE' : 'DECLINED';
    if (mine && CP.canTransition(mine.status, to, 'PARTICIPANT')) { mine.status = to; log(e, `${mine.name} → ${to}`); }
    state.trace = null; render(); return;
  }
  if (act === 'cancel-mine') { const mine = myPart(e); if (mine) cancel(e, mine, 'PARTICIPANT'); state.trace = null; render(); return; }
  if (act === 'sim-cancel') { const c = [...parts[e.id]].reverse().find((p) => p.status === 'CONFIRMED' && !p.userId.startsWith('u-sanne') && !p.userId.startsWith('u-daan')); if (c) cancel(e, c, 'PARTICIPANT'); return; }
  if (act === 'cap') return setCapacity(e, Number(b.dataset.d));
  if (act === 'fill') { if (!state.proposal[e.id]) state.proposal[e.id] = { trigger: 'MANUAL', createdAt: new Date() }; log(e, 'Organizer asked for a distribution proposal'); render(); return; }
  if (act === 'dismiss') { delete state.proposal[e.id]; state.selected.clear(); log(e, 'Proposal dismissed'); render(); return; }
  if (act === 'approve-run') return approveRun(e, buildProposal(e));
  if (act === 'approve') {
    const p = parts[e.id].find((x) => x.id === b.dataset.id);
    const before = snapshot(e);
    const outcome = CP.decideReservation({ capacity: e.capacity, confirmedCount: before.confirmed, activeHolds: 0, existingStatus: null });
    if (CP.canTransition(p.status, outcome, 'SYSTEM')) {
      p.status = outcome;
      if (outcome === 'WAITLISTED') p.position = Math.max(0, ...parts[e.id].map((x) => x.position || 0)) + 1;
      log(e, `Approved ${p.name} → ${outcome}`);
    }
    afterCapacityChange(e, before); return;
  }
  if (act === 'row') {
    const p = parts[e.id].find((x) => x.id === b.dataset.id);
    const to = b.dataset.to;
    if (!CP.canTransition(p.status, to, 'ORGANIZER')) return;
    const before = snapshot(e);
    const freed = CP.releasesPlace(p.status, to);
    p.status = to; p.position = null;
    log(e, `${p.name} → ${to}${freed ? ' · place released' : ''}`);
    if (freed) { state.cancellations[e.id]++; if (e.waitlistMode === 'AUTO_PROMOTE') promote(e); }
    afterCapacityChange(e, before); return;
  }
});

document.addEventListener('change', (ev) => {
  const t = ev.target;
  const e = env();
  const act = t.dataset.act;
  if (act === 'filter') { state.statusFilter = t.value; render(); }
  else if (act === 'pol') { e.policy = { ...e.policy, [t.dataset.key]: t.value, version: e.policy.version + 1 }; log(e, `Policy v${e.policy.version}: ${t.dataset.key} = ${t.value}`); render(); }
  else if (act === 'pol-disc') { e.policy = { ...e.policy, discoverable: t.checked, version: e.policy.version + 1 }; log(e, `Policy v${e.policy.version}: discoverable = ${t.checked}`); render(); }
  else if (act === 'dist') { e.distribution = { ...e.distribution, [t.dataset.key]: t.value, version: e.distribution.version + 1 }; log(e, `Distribution: ${t.dataset.key} = ${t.value}`); render(); }
  else if (act === 'allow') { persona().allowSuggest = t.checked; render(); }
  else if (act === 'pick') { if (t.checked) state.selected.add(t.dataset.id); else state.selected.delete(t.dataset.id); render(); }
});

// Initial trigger pass (e.g. low utilisation close to the start), then first render.
for (const e of envs) {
  const s = snapshot(e);
  for (const f of DS.evaluateTriggers({ policy: e.distribution, previous: null, current: trig(e, s), startsAt: e.startsAt, now: NOW, alreadyFired: [] })) {
    state.fired[e.id].push(f.key);
    log(e, `Trigger ${f.trigger} → ${f.action}: ${f.note}`);
    if (f.action === 'CREATE_PROPOSAL') state.proposal[e.id] = { trigger: f.trigger, createdAt: new Date() };
  }
}
$('#loading')?.remove();
render();
window.__amPrototype = { envs, parts, state };
