"""Local prototype server for A=M Environment Intelligence.

Serves `prototype/` as the site root and, read-only, the two source folders
the prototype loads at runtime: `/src/...` and `/tests/...` from the
repository. Nothing else in the repository is reachable (no .env, no
package files). Binds to 127.0.0.1 only.

Usage: python3 prototype/serve.py [port]   (default 8765)
"""
import http.server
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(ROOT)
ALLOWED_REPO_DIRS = (os.path.join(REPO, "src"), os.path.join(REPO, "tests"))
FORBIDDEN = os.path.join(ROOT, "__forbidden__")


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".ts": "text/plain; charset=utf-8",
        ".js": "text/javascript; charset=utf-8",
        ".json": "application/json",
    }

    def translate_path(self, path):
        p = path.split("?", 1)[0].split("#", 1)[0]
        if p.startswith("/src/") or p.startswith("/tests/"):
            full = os.path.normpath(os.path.join(REPO, p.lstrip("/")))
            if any(full.startswith(d + os.sep) for d in ALLOWED_REPO_DIRS):
                return full
            return FORBIDDEN
        full = os.path.normpath(os.path.join(ROOT, p.lstrip("/")))
        return full if full == ROOT or full.startswith(ROOT + os.sep) else FORBIDDEN

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    print(f"A=M prototype on http://localhost:{port}/", flush=True)
    http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
