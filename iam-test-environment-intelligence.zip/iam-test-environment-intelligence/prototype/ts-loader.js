/**
 * Loads the repository's real TypeScript modules in the browser.
 *
 * Fetches `/src/...` or `/tests/...` (served read-only by serve.py),
 * transpiles with the TypeScript compiler (global `ts`, loaded from a CDN),
 * rewrites relative imports to blob URLs and imports the result. Type-only
 * imports disappear during transpilation. `node:test` and
 * `node:assert/strict` map to small browser shims (see node-shims.js).
 *
 * This keeps one source of truth: the prototype runs the same code that is
 * meant to ship, not a copy.
 */
const cache = new Map();
const shims = new Map();

export function registerShim(specifier, url) {
  shims.set(specifier, url);
}

const IMPORT_RE = /(?:import|export)\s[^'"]*?from\s*(['"])([^'"]+)\1|import\s*(['"])([^'"]+)\3/g;

export function loadTs(path) {
  if (cache.has(path)) return cache.get(path);
  const promise = (async () => {
    const res = await fetch(path, { cache: 'no-store' });
    if (!res.ok) throw new Error(`Could not load ${path} (HTTP ${res.status})`);
    const source = await res.text();
    const out = globalThis.ts.transpileModule(source, {
      fileName: path,
      reportDiagnostics: true,
      compilerOptions: {
        module: globalThis.ts.ModuleKind.ESNext,
        target: globalThis.ts.ScriptTarget.ES2020,
        allowImportingTsExtensions: true,
        noEmit: false,
      },
    });
    const syntaxErrors = (out.diagnostics || []).filter((d) => d.category === globalThis.ts.DiagnosticCategory.Error);
    if (syntaxErrors.length) {
      const msg = syntaxErrors.map((d) => globalThis.ts.flattenDiagnosticMessageText(d.messageText, '\n')).join('; ');
      throw new Error(`Syntax error in ${path}: ${msg}`);
    }
    let code = out.outputText;
    const specifiers = new Set();
    for (const m of code.matchAll(IMPORT_RE)) specifiers.add(m[2] || m[4]);
    for (const spec of specifiers) {
      let url;
      if (shims.has(spec)) url = shims.get(spec);
      else if (spec.startsWith('.') || spec.startsWith('/')) url = (await loadTs(new URL(spec, location.origin + path).pathname)).url;
      else throw new Error(`${path} imports "${spec}", which is not available in the prototype`);
      code = code.split(`"${spec}"`).join(`"${url}"`).split(`'${spec}'`).join(`'${url}'`);
    }
    const url = URL.createObjectURL(new Blob([code + `\n//# sourceURL=${location.origin}${path}.js`], { type: 'text/javascript' }));
    const module = await import(url);
    return { url, module };
  })();
  cache.set(path, promise);
  return promise;
}

export async function loadEngine() {
  const base = '/src/server/environments/';
  const names = ['policy', 'eligibility', 'relevance', 'capacity', 'invitations', 'distribution'];
  const mods = await Promise.all(names.map((n) => loadTs(`${base}${n}.ts`).then((r) => r.module)));
  return Object.fromEntries(names.map((n, i) => [n, mods[i]]));
}
