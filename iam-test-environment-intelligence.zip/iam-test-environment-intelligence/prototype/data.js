/**
 * SAMPLE DATA for the Environment Intelligence prototype. Invented people,
 * hubs and environments; no real personal data. Shapes follow
 * src/domain/environments/types.ts.
 */
const H = 3_600_000;
const D = 24 * H;

export const HUBS = {
  'hub-amf': 'Amersfoort Hub',
  'hub-utr': 'Utrecht Makers',
};

export const SKILLS = { py: 'Python', ux: 'UX design', ml: 'Machine learning', pitch: 'Pitching' };

export const TERM_LABELS = {
  'format.network_event': 'Network event', 'format.workshop': 'Workshop', 'format.dinner': 'Dinner',
  'format.meetup': 'Meetup', 'format.social_hub': 'Social hub', 'format.session': 'Working session',
  'business.startups': 'Startups', 'business': 'Business & Entrepreneurship', 'networking.founders': 'Founders',
  'technology.artificial_intelligence': 'Artificial intelligence', 'technology': 'Technology & AI',
  'ventures.investors': 'Investors', 'networking.local_business': 'Local business', 'city.local_initiatives': 'Local initiatives',
  'creative.design': 'Design', 'creative': 'Creative & Media', 'networking': 'Networking & Community',
  'audience.entrepreneur': 'Entrepreneurs', 'audience.professional': 'Professionals', 'audience.creator': 'Creators',
  'audience.investor': 'Investors', 'audience.student': 'Students',
  'purpose.connect': 'Connect', 'purpose.learn': 'Learn', 'purpose.invest': 'Invest', 'purpose.create': 'Create', 'purpose.collaborate': 'Collaborate',
};
export const label = (code) => TERM_LABELS[code] || code;

const basePolicy = {
  version: 1, accessModel: 'PUBLIC', discoverable: true, registrationMode: 'OPEN', approvalMode: 'AUTO_WITHIN_CONDITIONS',
  autoConditions: [], eligibilityRules: [], guestPolicy: 'NONE', guestsPerMember: null, communityHubIds: [],
  crossCommunity: 'NONE', allowedPartnerHubIds: [],
};
const baseDistribution = {
  version: 1, mode: 'SUGGEST_ALL', approvalMethod: 'PERSONAL_INVITATION_ONLY',
  triggers: [{ type: 'CANCELLATION', minCount: 1 }, { type: 'UTILISATION_BELOW', percent: 70, checkAtHoursBeforeStart: 120 }, { type: 'CAPACITY_INCREASED' }, { type: 'WAITLIST_ACTIVATED' }],
  maxInvitationsPerRun: 25, minHoursBeforeStart: 24,
};

export function buildEnvironments(now) {
  const at = (days, hour) => { const d = new Date(now.getTime() + days * D); d.setHours(hour, 0, 0, 0); return d.toISOString(); };
  return [
    {
      id: 'env-lab', title: 'A=M Business Lab', kind: 'EVENT', status: 'PUBLISHED', startsAt: at(3, 19), capacity: 40,
      venue: 'Amicitia, Amersfoort', format: 'format.network_event', categories: ['business.startups', 'networking.founders'],
      audience: { categoryCodes: ['business.startups', 'networking.founders'], audienceCodes: ['audience.entrepreneur', 'audience.professional'], purposeCodes: ['purpose.connect'], targetSkillIds: ['pitch'], communityHubIds: [], locationScope: 'scope.local', city: 'Amersfoort', countryCode: 'NL' },
      policy: { ...basePolicy },
      distribution: { ...baseDistribution },
      waitlistMode: 'AUTO_PROMOTE',
      blurb: 'Monthly evening for founders and professionals: three pitches, open networking, drinks.',
    },
    {
      id: 'env-ai', title: 'AI Builders Workshop', kind: 'EVENT', status: 'PUBLISHED', startsAt: at(9, 13), capacity: 16,
      venue: 'Hof, Amersfoort', format: 'format.workshop', categories: ['technology.artificial_intelligence'],
      audience: { categoryCodes: ['technology.artificial_intelligence'], audienceCodes: ['audience.professional', 'audience.entrepreneur'], purposeCodes: ['purpose.learn'], targetSkillIds: ['py', 'ml'], communityHubIds: [], locationScope: 'scope.regional', city: 'Amersfoort', countryCode: 'NL' },
      policy: {
        ...basePolicy, accessModel: 'CURATED', registrationMode: 'REQUEST', approvalMode: 'AUTO_WITHIN_CONDITIONS',
        autoConditions: [{ type: 'closes_hours_before_start', hours: 48 }],
        eligibilityRules: [
          { type: 'required_skill', skillId: 'py', label: 'Python', mustBeVerified: false },
          { type: 'min_experience_level', level: 'level.intermediate', skillId: 'py' },
        ],
      },
      distribution: { ...baseDistribution, approvalMethod: 'MANUAL_APPROVAL' },
      waitlistMode: 'AUTO_PROMOTE',
      blurb: 'Hands-on afternoon building small AI agents. Bring a laptop. Intermediate Python required.',
    },
    {
      id: 'env-dinner', title: 'Investor Dinner', kind: 'EVENT', status: 'PUBLISHED', startsAt: at(14, 19), capacity: 12,
      venue: 'Private venue, Amersfoort', format: 'format.dinner', categories: ['ventures.investors'],
      audience: { categoryCodes: ['ventures.investors'], audienceCodes: ['audience.investor', 'audience.entrepreneur'], purposeCodes: ['purpose.invest'], targetSkillIds: [], communityHubIds: [], locationScope: 'scope.local', city: 'Amersfoort', countryCode: 'NL' },
      policy: { ...basePolicy, accessModel: 'PRIVATE', discoverable: false, registrationMode: 'INVITE_ONLY', approvalMode: 'INVITATION_ONLY' },
      distribution: { ...baseDistribution, mode: 'NONE' },
      waitlistMode: 'MANUAL',
      blurb: 'Closed dinner for investors and selected founders. By personal invitation only.',
    },
    {
      id: 'env-meetup', title: 'Amersfoort Hub Meetup', kind: 'EVENT', status: 'PUBLISHED', startsAt: at(6, 18), capacity: 30,
      venue: 'De Nieuwe Stad, Amersfoort', format: 'format.meetup', categories: ['networking.local_business', 'city.local_initiatives'],
      audience: { categoryCodes: ['networking.local_business', 'city.local_initiatives'], audienceCodes: [], purposeCodes: ['purpose.connect'], targetSkillIds: [], communityHubIds: ['hub-amf'], locationScope: 'scope.local', city: 'Amersfoort', countryCode: 'NL' },
      policy: {
        ...basePolicy, accessModel: 'COMMUNITY', discoverable: true, communityHubIds: ['hub-amf'], guestPolicy: 'MEMBERS_PLUS_N', guestsPerMember: 1,
        crossCommunity: 'ALLOWED_HUBS', allowedPartnerHubIds: ['hub-utr'], approvalMode: 'AUTO_WITHIN_CONDITIONS', autoConditions: [{ type: 'hub_membership', hubIds: ['hub-amf'] }],
      },
      distribution: { ...baseDistribution, mode: 'SUGGEST_HUBS' },
      waitlistMode: 'OFFER',
      blurb: 'Monthly meetup for hub members. Each member may bring one guest; Utrecht Makers members may apply.',
    },
    {
      id: 'env-hub', title: 'Amersfoort Hub', kind: 'HUB', status: 'PUBLISHED', startsAt: null, capacity: null,
      venue: 'Amersfoort', format: 'format.social_hub', categories: ['networking.local_business'],
      audience: { categoryCodes: ['networking.local_business'], audienceCodes: [], purposeCodes: ['purpose.connect', 'purpose.collaborate'], targetSkillIds: [], communityHubIds: ['hub-amf'], locationScope: 'scope.local', city: 'Amersfoort', countryCode: 'NL' },
      policy: { ...basePolicy, accessModel: 'PUBLIC', registrationMode: 'REQUEST', approvalMode: 'MANUAL' },
      distribution: { ...baseDistribution, mode: 'NONE', triggers: [] },
      waitlistMode: 'MANUAL',
      blurb: 'The local A=M community: makers, founders and initiatives in and around Amersfoort.',
    },
    {
      id: 'env-studio', title: 'Creative Studio Session', kind: 'EVENT', status: 'PUBLISHED', startsAt: at(11, 10), capacity: 10,
      venue: 'Hogeweg, Amersfoort', format: 'format.session', categories: ['creative.design'],
      audience: { categoryCodes: ['creative.design'], audienceCodes: ['audience.creator'], purposeCodes: ['purpose.create'], targetSkillIds: ['ux'], communityHubIds: [], locationScope: 'scope.regional', city: 'Amersfoort', countryCode: 'NL' },
      policy: { ...basePolicy, accessModel: 'CURATED', discoverable: false, registrationMode: 'REQUEST', approvalMode: 'MANUAL', eligibilityRules: [{ type: 'profile_type', audienceCodes: ['audience.creator'] }] },
      distribution: { ...baseDistribution, mode: 'SUGGEST_INTERESTED', approvalMethod: 'MANUAL_APPROVAL' },
      waitlistMode: 'MANUAL',
      blurb: 'Hidden, curated design session. Only visible to invitees.',
    },
  ];
}

/** Personas the viewer can switch between. */
export const PERSONAS = [
  { id: 'organizer', name: 'Organizer', note: 'Owner of every sample environment', organizer: true },
  {
    id: 'sanne', name: 'Sanne V.', note: 'Entrepreneur · Amersfoort Hub member · Python (intermediate)',
    profile: { userId: 'u-sanne', profileContextId: 'ctx-business', audienceCodes: ['audience.entrepreneur'], interestCodes: ['technology.artificial_intelligence', 'business.startups'], purposeCodes: ['purpose.connect', 'purpose.learn'], skills: [{ skillId: 'py', level: 'level.intermediate', verified: false }, { skillId: 'pitch', level: 'level.advanced', verified: true }], countryCode: 'NL', city: 'Amersfoort', hubIds: ['hub-amf'], organizationIds: [], completedEnvironmentIds: [], birthYear: 1992 },
    allowSuggest: true,
  },
  {
    id: 'daan', name: 'Daan K.', note: 'Creator · Utrecht Makers member · UX (advanced, verified)',
    profile: { userId: 'u-daan', profileContextId: 'ctx-creative', audienceCodes: ['audience.creator'], interestCodes: ['creative.design', 'technology'], purposeCodes: ['purpose.create'], skills: [{ skillId: 'ux', level: 'level.advanced', verified: true }], countryCode: 'NL', city: 'Utrecht', hubIds: ['hub-utr'], organizationIds: [], completedEnvironmentIds: [], birthYear: 1997 },
    allowSuggest: false,
  },
  { id: 'anon', name: 'Visitor', note: 'Not signed in', anonymous: true },
];

const FIRST = ['Lotte', 'Bram', 'Noor', 'Jesse', 'Fleur', 'Thijs', 'Iris', 'Ruben', 'Eva', 'Milan', 'Anouk', 'Sem', 'Lisa', 'Luuk', 'Femke', 'Jens', 'Roos', 'Stijn', 'Yara', 'Koen', 'Maud', 'Tim', 'Sara', 'Joris'];
let seq = 0;
const person = () => { const n = FIRST[seq % FIRST.length]; seq++; return { userId: `u-${seq}`, name: `${n} ${String.fromCharCode(65 + (seq * 7) % 26)}.` }; };

/** Seed participations per environment: [status, count, source]. */
const SEED = {
  'env-lab': [['CONFIRMED', 37, 'SELF'], ['MAYBE', 2, 'SELF'], ['INVITED', 3, 'INVITATION'], ['NO_RESPONSE', 2, 'INVITATION']],
  'env-ai': [['CONFIRMED', 16, 'SELF'], ['WAITLISTED', 3, 'SELF'], ['PENDING_APPROVAL', 1, 'SELF']],
  'env-dinner': [['CONFIRMED', 8, 'INVITATION'], ['INVITED', 3, 'INVITATION'], ['DECLINED', 1, 'INVITATION']],
  'env-meetup': [['CONFIRMED', 18, 'HUB_MEMBERSHIP'], ['MAYBE', 3, 'HUB_MEMBERSHIP']],
  'env-hub': [['CONFIRMED', 126, 'HUB_MEMBERSHIP'], ['REQUESTED', 4, 'SELF']],
  'env-studio': [['CONFIRMED', 6, 'INVITATION'], ['PENDING_APPROVAL', 2, 'SELF'], ['INVITED', 1, 'INVITATION']],
};

export function buildParticipants() {
  seq = 0;
  const out = {};
  for (const [envId, rows] of Object.entries(SEED)) {
    const list = [];
    let pos = 1;
    for (const [status, count, source] of rows) {
      for (let i = 0; i < count; i++) {
        const p = person();
        list.push({ id: `${envId}-${p.userId}`, ...p, status, source, position: status === 'WAITLISTED' ? pos++ : null });
      }
    }
    out[envId] = list;
  }
  // Persona-specific starting points.
  out['env-dinner'].push({ id: 'env-dinner-u-daan', userId: 'u-daan', name: 'Daan K.', status: 'INVITED', source: 'INVITATION', position: null });
  return out;
}

/** Daan is Sanne's nominated guest for the hub meetup. */
export const NOMINATED_GUESTS = { 'env-meetup': ['u-daan'] };

/**
 * Candidate pool for "Fill available spots": people with declared profiles
 * and their own invitation preferences. Most opted in; some did not.
 */
export function buildCandidatePool() {
  const mk = (id, name, o, allowSuggest, channel = 'IN_APP', categoryCodes = null) => ({
    id, name, allowSuggest,
    profile: { userId: id, profileContextId: null, audienceCodes: [], interestCodes: [], purposeCodes: [], skills: [], countryCode: 'NL', city: 'Amersfoort', hubIds: [], organizationIds: [], completedEnvironmentIds: [], birthYear: 1990, ...o },
    preferences: [{ profileContextId: null, kind: 'DISTRIBUTION_SUGGESTION', categoryCodes, channel, allowSuggestToOrganizers: allowSuggest }],
  });
  return [
    mk('c-1', 'Esther B.', { audienceCodes: ['audience.entrepreneur'], interestCodes: ['business.startups'], skills: [{ skillId: 'pitch', level: 'level.intermediate', verified: false }], hubIds: ['hub-amf'] }, true),
    mk('c-2', 'Ravi P.', { audienceCodes: ['audience.professional'], interestCodes: ['technology.artificial_intelligence'], skills: [{ skillId: 'py', level: 'level.advanced', verified: true }, { skillId: 'ml', level: 'level.intermediate', verified: false }] }, true),
    mk('c-3', 'Mila de G.', { audienceCodes: ['audience.creator'], interestCodes: ['creative.design'], skills: [{ skillId: 'ux', level: 'level.intermediate', verified: false }], city: 'Utrecht', hubIds: ['hub-utr'] }, true),
    mk('c-4', 'Tom H.', { audienceCodes: ['audience.entrepreneur'], interestCodes: ['business.startups', 'technology'], city: 'Leusden' }, true),
    mk('c-5', 'Aylin S.', { audienceCodes: ['audience.professional'], interestCodes: ['networking.founders'], skills: [{ skillId: 'py', level: 'level.beginner', verified: false }] }, true),
    mk('c-6', 'Peter V.', { audienceCodes: ['audience.investor'], interestCodes: ['ventures.investors'] }, true),
    mk('c-7', 'Nina R.', { audienceCodes: ['audience.student'], interestCodes: ['technology.artificial_intelligence'], skills: [{ skillId: 'py', level: 'level.intermediate', verified: false }], city: 'Utrecht' }, true),
    mk('c-8', 'Bas L.', { audienceCodes: ['audience.entrepreneur'], interestCodes: ['business.startups'], hubIds: ['hub-amf'] }, false),
    mk('c-9', 'Sophie W.', { audienceCodes: ['audience.creator'], interestCodes: ['creative'], city: 'Amsterdam' }, true, 'NONE'),
    mk('c-10', 'Hugo M.', { audienceCodes: ['audience.professional'], interestCodes: ['business'], skills: [{ skillId: 'pitch', level: 'level.advanced', verified: true }] }, true, 'EMAIL', ['business']),
    mk('c-11', 'Lina O.', { audienceCodes: ['audience.professional'], interestCodes: ['city.local_initiatives'], hubIds: ['hub-amf'] }, true),
    mk('c-12', 'Wouter T.', { audienceCodes: ['audience.creator'], interestCodes: ['creative.design', 'technology.artificial_intelligence'], skills: [{ skillId: 'ux', level: 'level.advanced', verified: true }, { skillId: 'py', level: 'level.intermediate', verified: true }], city: 'Hilversum' }, true),
  ];
}
