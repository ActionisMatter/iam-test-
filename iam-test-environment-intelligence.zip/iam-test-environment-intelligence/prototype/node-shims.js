/**
 * Minimal browser stand-ins for `node:test` and `node:assert/strict`, just
 * enough for the repository's unit tests: describe / it, and
 * assert.equal / deepEqual / ok (strict semantics).
 */
import { registerShim } from './ts-loader.js';

export const registry = { tests: [] };
globalThis.__amTestRegistry = registry;

const testSource = `
const reg = globalThis.__amTestRegistry;
const stack = [];
export function describe(name, fn) { stack.push(name); try { fn(); } finally { stack.pop(); } }
export function it(name, fn) { reg.tests.push({ suite: stack.join(' › '), name, fn, file: reg.currentFile }); }
export const test = it;
`;

const assertSource = `
class AssertionError extends Error { constructor(message) { super(message); this.name = 'AssertionError'; } }
const fmt = (v) => { try { return JSON.stringify(v); } catch { return String(v); } };
function isDeepStrictEqual(a, b) {
  if (Object.is(a, b)) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;
  if (Object.getPrototypeOf(a) !== Object.getPrototypeOf(b)) return false;
  if (Array.isArray(a)) {
    if (a.length !== b.length) return false;
    return a.every((x, i) => isDeepStrictEqual(x, b[i]));
  }
  const ka = Object.keys(a), kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  return ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && isDeepStrictEqual(a[k], b[k]));
}
function equal(actual, expected, message) {
  if (!Object.is(actual, expected)) throw new AssertionError((message ? message + ': ' : '') + 'expected ' + fmt(expected) + ', got ' + fmt(actual));
}
function deepEqual(actual, expected, message) {
  if (!isDeepStrictEqual(actual, expected)) throw new AssertionError((message ? message + ': ' : '') + 'expected ' + fmt(expected) + ', got ' + fmt(actual));
}
function ok(value, message) { if (!value) throw new AssertionError(message || 'expected a truthy value, got ' + fmt(value)); }
const assert = Object.assign((v, m) => ok(v, m), { equal, strictEqual: equal, deepEqual, deepStrictEqual: deepEqual, ok, AssertionError });
export default assert;
export { equal, deepEqual, ok, AssertionError };
`;

const blob = (src) => URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
registerShim('node:test', blob(testSource));
registerShim('node:assert/strict', blob(assertSource));
registerShim('node:assert', blob(assertSource));
