# iam-test- · A=M Environment Intelligence

Test repository for the **ACTION = MATTER Environment Intelligence Engine**: the rules that decide which people fit which environments (events, hubs, communities, workshops, trainings) and under which conditions they get in.

> **Status:** prototype. The engine functions are **IMPLEMENTED** and **TESTED in a browser runtime** (73/73 unit tests pass). Not yet run in Node, not typechecked, not connected to a database or to the A=M platform. All data in the prototype is invented sample data.

## What is in here

| Path | Content |
|---|---|
| `src/domain/environments/types.ts` | Domain types: statuses, access models, policies, eligibility rules, profile context, triggers |
| `src/server/environments/` | Pure functions, no I/O: `policy.ts` (access + approval), `eligibility.ts`, `relevance.ts`, `capacity.ts`, `invitations.ts`, `distribution.ts` (triggers, proposals) |
| `tests/environments/` | Table-driven unit tests (`node:test`) |
| `prototype/` | Browser prototype that runs the real `.ts` files, plus the A=M MAP prototype and a page that runs the tests |
| `docs/environment-intelligence/` | Engine specification and category taxonomy |

The engine answers six separate questions and never mixes them: **relevance** (does someone fit; never decides), **eligibility** (admission rules), **access** (may they register or request), **capacity** (is there room), **invitation** (may they be invited) and **approval** (who has to approve). An invitation never creates a confirmed registration; a capacity trigger never sends anything without an organizer's approval.

## Run

Unit tests (Node 22.6 or newer):

```bash
npm run test:unit
```

Typecheck:

```bash
npm install && npm run typecheck
```

Prototype on http://localhost:8765 (Python 3; loads the TypeScript compiler from jsDelivr):

```bash
npm run prototype
```

- `/` — Environments: switch persona (organizer, member, guest, visitor) and watch the engine decide, question by question.
- `/engine-tests.html` — runs the unit tests in the browser.
- `/map/` — A=M MAP prototype.

## Notes

- The specification refers to further documents (access policy, capacity & distribution, architecture, implementation plan). Those are kept out of this public repository because they describe the security state of the live platform.
- Map data: country outlines from [Natural Earth](https://www.naturalearthdata.com/) (public domain); Amersfoort roads, rail and waterways © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors, available under the Open Database License (ODbL).
