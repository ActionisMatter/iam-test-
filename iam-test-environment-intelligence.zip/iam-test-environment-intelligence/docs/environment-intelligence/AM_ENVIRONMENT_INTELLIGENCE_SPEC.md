# AM Environment Intelligence Engine — Specification

**Status:** PROPOSED · **Implementation status of everything in this document:** NOT IMPLEMENTED, unless a row says EXISTS
**Date:** 2026-11-23 · **Target repository:** `Raziuuu/A-M`
**Principle:** *The right people in the right environments.*

Related: `AM_CATEGORY_TAXONOMY_V1.md` · `AM_ACCESS_AUDIENCE_POLICY_SPEC.md` · `AM_CAPACITY_DISTRIBUTION_SPEC.md` · `AM_EVENT_INTELLIGENCE_ARCHITECTURE.md` · `AM_EVENT_INTELLIGENCE_IMPLEMENTATION_PLAN.md`

---

## 1. What changes compared with "Event Intelligence"

Event Intelligence treated events as the unit. Environment Intelligence generalises this: **an environment is any place, gathering or group that people can join**: an event, a hub, a community, a workshop, a training, a programme or a project space. Events become one *kind* of environment.

Two consequences:

1. Access, eligibility, capacity, invitations, approval and analytics are built **once** and work for every kind. No separate invitation logic for hubs and for events.
2. The existing `events` and `hubs` tables stay and keep working. They are linked to a new generic `environments` record instead of being replaced (decision E-07).

## 2. Engine components

| # | Component | Responsibility | Existing basis | Status |
|---|---|---|---|---|
| 1 | Environment Creation | create, edit, publish, unpublish and archive environments of every kind | `events`, `hubs` tables; `POST /api/events`, `/api/hubs` (admin-only after V17 patch) | EXTEND |
| 2 | Categorization Engine | apply taxonomy terms to environments and profiles | none (`event_type`, `topics[]` free text) | NEW (see taxonomy) |
| 3 | Profile-to-Environment Mapping | describe a person's profiles, interests, skills, goals and invitation preferences in taxonomy terms | `profiles`, `profile_skills`, skills catalogue | EXTEND |
| 4 | Access & Audience Policy Engine | who may see, request, join or be invited | RLS "events viewable by all" | NEW (see access spec) |
| 5 | Eligibility Engine | hard admission requirements | none | NEW |
| 6 | Audience Matching | explainable relevance suggestions, never a gate | `/api/ai` mock string-overlap (returns a numeric score, conflicts with D-11) | NEW, replaces the mock for this use |
| 7 | Capacity Trigger Engine | capacity accounting, waitlist, triggers | `events.capacity`, `attendees_count` (drifting counter) | EXTEND (see capacity spec) |
| 8 | Invitation Distribution | prepare, approve, send and track invitations | none | NEW, depends on Notifications |
| 9 | Approval Workflow | organiser approval of requests, candidates and distribution runs | AI BOS `Approval` pattern (append-only, latest wins) as design reference only | NEW |
| 10 | Participation & Attendance Analytics | RSVP, attendance, utilisation, replacement and new connections | `/dashboard/analytics` is hard-coded | NEW |
| — | Access passes and check-in | per-participation token, QR scan, manual fallback | none | NEW (the "Access Engine" of the Identity & Commerce proposal) |

## 3. The six questions are separate

Every decision about a person and an environment goes through six separate questions. Each has its own function, its own inputs and its own stored result. They are never combined into one score.

| # | Question | Function | Inputs | Output | Hard gate? |
|---|---|---|---|---|---|
| 1 | **Audience relevance:** does this person fit this environment? | `assessRelevance(profileContext, environment)` | taxonomy overlap, declared interests, skills, audience types, location, language | `{ level: high/medium/low/none, reasons[] }`; reasons, no numeric score shown (D-11) | **No.** Only ranks suggestions |
| 2 | **Eligibility:** does the person meet the admission requirements? | `checkEligibility(profileContext, environment.requirements)` | requirement rules: required skill (optionally verified), minimum level, membership of hub X, profile type, age 18+ only where legally needed | `{ eligible: bool, unmet[] }` | Yes, if the organiser set requirements |
| 3 | **Access permission:** may this person register or request? | `checkAccess(actor, environment.accessPolicy)` | access model, discoverability, actor's relation (member, invitee, guest of member) | `{ action: register / request / none, reason }` | Yes |
| 4 | **Capacity:** is there room? | `reserveCapacity(environmentId, …)`, inside a DB transaction | capacity rules, holds, waitlist | `{ outcome: confirmed / waitlisted / held / full }` | Yes, transactional |
| 5 | **Invitation:** may this person be invited? | `canInvite(organizer, recipientContext, environment)` | organiser rights, recipient preferences and consent, frequency caps, duplicates, suppression list | `{ allowed: bool, channel, reason }` | Yes, for invitations |
| 6 | **Approval:** who must approve participation? | `approvalRequirement(environment.policy, path)` | approval mode, path (self-registration, request, distribution, waitlist promotion) | `{ required: none / organizer / hub_admin, … }` | Yes, when required |

### Evaluation order for a self-registration

```
checkAccess ─▶ checkEligibility ─▶ approvalRequirement ─┬─ none ─────▶ reserveCapacity ─▶ CONFIRMED / WAITLISTED
                                                         └─ organizer ─▶ PENDING_APPROVAL ─(approved)─▶ reserveCapacity
```

Relevance is not in this chain. A person who is "not relevant" but is allowed in, eligible and has room can still register.

### Evaluation order for a distribution suggestion

```
assessRelevance (rank candidates) ─▶ checkEligibility (filter) ─▶ canInvite (filter) ─▶ organiser approves run ─▶ invitation sent
                                                                                       (no registration is created)
```

### Rules that keep these apart (enforced in code and tests)

- R1. Relevance never blocks or grants anything.
- R2. An invitation never creates a confirmed registration. Accepting an invitation runs the self-registration chain from `checkAccess` onward.
- R3. Eligibility results are recalculated when requirements change; stored results carry the policy version.
- R4. Capacity is only decided inside the database transaction (see capacity spec), never from a cached count.
- R5. Approval is recorded as an append-only decision with actor, time, policy version and reason.
- R6. Non-response, inactivity or declined invitations are never used as evidence of disinterest, and never lower someone's relevance.

## 4. Profile-to-Environment Mapping

### 4.1 Profile context

Matching works on a **profile context**, not on a raw user. This follows the decision "one account, several profiles" (Individual, Professional, Entrepreneur, Creator, Organization, Community/Hub).

| Element | Source | Status |
|---|---|---|
| Profile types a user holds | **Missing.** The repo has one `profiles` row per user; account type lives only in auth metadata (V17 matrix B) | Blocked on E-08 (multi-profile model) |
| Interests | new `profile_terms` (facet `category`), self-declared only | NEW |
| Skills (with verification state) | `profile_skills` + skills catalogue (canonical per D-09) | EXISTS, partial |
| Goals | new `profile_terms` (facet `purpose`) | NEW |
| Location | `profiles.city`, `country_code` (to be linked to Location records later) | EXISTS |
| Hub and organisation memberships | `hub_members` (never written today); organisations missing | PARTIAL / MISSING |
| Invitation preferences per context | new `invitation_preferences` (see access spec §6) | NEW |
| Discoverability for distribution | new opt-in flag per profile context, **default off** | NEW |

Until E-08 is decided, the design uses `profile_context_id` as a nullable column next to `user_id` on participations and invitations. A user then acts through their single profile now and can pick a context later without a migration that rewrites history.

### 4.2 Context rules

- A participation records which profile context was used. A business booking or business event does not show up in a social context (from the Identity & Commerce proposal).
- Invitations go to the context the recipient chose for that kind of invitation. With no preference, the invitation goes nowhere; there is no "send to all contexts" fallback.
- Organisation profiles act through members with an organiser role, never as an anonymous organisation.

## 5. Environment entity (summary; full model in the architecture document)

```
environments
  id UUID PK, kind (EVENT | PROGRAM | HUB | PROJECT_SPACE)
  owner_organization_id UUID NULL  -- tenant (E-02); NULL only for platform-owned
  owner_profile_id UUID NULL        -- for individuals' environments, if E-12 allows
  title, description, primary_category_code, format_code, location_scope_code
  location_id NULL, online_url NULL
  status: DRAFT | PUBLISHED | UNPUBLISHED | CANCELLED | ARCHIVED
  policy_version INT
  created_by, created_at, updated_at, published_at
events.environment_id  UUID UNIQUE REFERENCES environments  -- EXTEND existing table
hubs.environment_id    UUID UNIQUE REFERENCES environments  -- EXTEND existing table
```

Kind-specific data stays in the kind table (dates and times on `events`, slug and member counts on `hubs`). Shared behaviour reads `environments`.

## 6. Participation (summary)

One canonical participation record for every kind (decision E-09):

```
environment_participants
  id, environment_id, user_id, profile_context_id NULL
  status: INVITED | REQUESTED | PENDING_APPROVAL | CONFIRMED | MAYBE | DECLINED | CANCELLED | WAITLISTED | CHECKED_IN | NO_RESPONSE | REMOVED
  source: SELF | INVITATION | DISTRIBUTION | WAITLIST_PROMOTION | ORGANIZER_ADDED | HUB_MEMBERSHIP
  role: PARTICIPANT | GUEST | SPEAKER | ORGANIZER | STAFF
  UNIQUE (environment_id, user_id)
environment_participant_events (append-only status history)
```

Hub membership is a participation with `kind = HUB`. `event_attendees` and `hub_members` become compatibility views once data is moved. The V17 audit found that the app never writes to them; whether production holds rows is UNKNOWN and must be checked before migrating.

`REQUESTED`, `PENDING_APPROVAL` and `REMOVED` are added to the directive's eight statuses. They are needed for PRIVATE and CURATED access and for organiser removal. `NO_RESPONSE` is never turned into `DECLINED` automatically.

## 7. Flows

### 7.1 Participant flows

1. **Discover:** browse or search environments (list, map, hub page). Only environments the person may see appear (access spec §2).
2. **Open:** environment page shows programme, location, the person's own status, available places (as a number or as "places available", per organiser setting), and the action they are allowed: *Register*, *Request to join*, *Join waitlist*, or nothing.
3. **Register / request:** runs the chain in §3. The result is shown with a clear reason, for example "Waitlisted: you are number 4" or "Request sent to the organiser".
4. **Respond to an invitation:** accept (→ chain from `checkAccess`), maybe, decline, or "don't invite me for this kind again".
5. **Change RSVP:** confirmed → cancelled releases the place; maybe → confirmed goes through capacity.
6. **Pass:** confirmed participants see an access pass (QR with an opaque token) in "My passes".
7. **Check-in:** staff scan the token; the person sees "Checked in".
8. **After:** connect with participants who made themselves visible; manage their own visibility in the participant list.
9. **Preferences:** choose per profile context which invitation kinds they accept and whether they may be suggested to organisers at all.

### 7.2 Organiser flows

1. **Create:** pick kind and format → defaults for access and capacity are filled in (taxonomy §5) → set category, audience, level, location and capacity → save as DRAFT.
2. **Set policy:** access model, eligibility requirements, approval method, guest rules, distribution mode and triggers.
3. **Publish:** validation checks that required fields and a consistent policy exist (e.g. CURATED needs an approver).
4. **Manage participants:** filter by status and source, approve or decline requests, add people manually, move people from the waitlist, check people in manually.
5. **Invite:** pick recipients (people, hubs, organisations) → preview the eligible audience (counts and reasons, no private data of other organisations) → write the message → send (only after notifications and consent are verified).
6. **Fill available spots:** a trigger fires or the organiser clicks → the engine proposes candidates and groups → the organiser selects and approves → invitations are sent → resulting registrations are tracked.
7. **Analyse:** dashboard with the directive's metrics, each computed from stored participation data.

## 8. Matching rules (Audience Matching)

- **Explainable by construction:** every suggestion lists its reasons ("shares 3 interests: AI, data, startups", "member of Amersfoort Hub", "skill: UX design (verified)").
- **Human decision:** suggestions are recommendations (V17 §10.3). Only an organiser decision turns them into invitations. This follows the V17 legal boundary: no autonomous allocation and no automatic ranking of people shown as a judgement.
- **No numeric score in the UI** (D-11). Levels (high, medium, low) may be shown with their reasons.
- **Inputs are declared data only:** taxonomy terms, skills, memberships, location and explicit preferences. No behavioural tracking (page views, clicks, inactivity) unless a separate, explicit user preference allows it. That preference is not part of V1.
- **Candidate pool:** only people whose profile context is opted in to "may be suggested to organisers", plus members of hubs whose hub admin approved cross-community distribution.
- **Deterministic in V1:** rule-based overlap. Any later model-based ranking needs the V17 §10 evaluation gate (G4).

## 9. Security and privacy requirements (engine-wide)

1. Every read and write goes through server-side authorization (V17 §12.1). RLS is defence in depth.
2. Participant lists are visible only to the environment's organisers and staff, and to participants who opted in to be visible to other participants. Never to other organisations or hub admins.
3. Distribution previews to an organiser show aggregate counts per group and named people only if those people opted in to being suggested.
4. No inference of special-category data; no special-category taxonomy terms.
5. Access-pass tokens are random, stored hashed, scoped to one participation, revocable, and carry no personal data. The personal identity QR is never accepted as an access pass.
6. Every policy change, approval, distribution run, check-in and capacity change is written to the audit log with actor, tenant and policy version.

## 10. Acceptance criteria (engine level)

- [ ] The six questions are separate functions with separate unit tests; no function combines two of them.
- [ ] Relevance can be set to "none" for a person who still successfully registers (proves R1).
- [ ] Accepting an invitation for a full environment results in WAITLISTED, not CONFIRMED (proves R2 and R4).
- [ ] An existing event created through `/api/events` appears as an environment of kind EVENT, and the existing Events & Hubs page keeps working.
- [ ] A user who never opted in is never in a distribution candidate list.
- [ ] Participant lists return 403 for a hub admin who is not an organiser of the environment.
