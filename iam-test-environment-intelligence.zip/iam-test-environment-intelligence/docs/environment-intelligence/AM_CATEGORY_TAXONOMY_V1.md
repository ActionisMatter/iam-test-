# AM Category Taxonomy V1

**Status:** PROPOSED — not implemented, needs founder approval (decision E-03)
**Date:** 2026-11-23 · **Target repository:** `Raziuuu/A-M`
**Part of:** Environment Intelligence document set (see `AM_EVENT_INTELLIGENCE_ARCHITECTURE.md`)

The taxonomy is the shared vocabulary that environments, profiles, matching and analytics all use. It is one platform-wide system, not a list per module.

---

## 1. Design rules

1. **One taxonomy, several facets.** A single `taxonomy_terms` table holds every controlled term, split by `facet`. No separate category table for events, another for hubs and another for interests.
2. **Skills are not duplicated.** Required skills use the existing skills catalogue (`niches`, `skills`, `skill_aliases`, `profile_skills`; canonical source per V17 D-09). The taxonomy refers to it; it does not copy it.
3. **Stable codes.** Every term has an immutable `code` (`business.startups`). Labels can change and be translated; codes cannot. Retired terms get `status = 'retired'` and a `replaced_by` code, never a delete.
4. **Central terms decide matching; organiser tags do not.** Organisers may add free tags for display and search. Tags never count as eligibility rules and never feed matching unless an admin maps a tag to a central term.
5. **Many-to-many everywhere.** An environment can have several categories; a person can have many interests. Each environment has exactly one *primary* category for navigation and reporting.
6. **No sensitive facets.** The taxonomy has no terms for health, religion, ethnicity, sexual orientation, political opinion, union membership or similar special-category data (GDPR art. 9), and the system never infers them.

## 2. Facets

| Facet | Applies to | Cardinality on an environment | Used for |
|---|---|---|---|
| `theme` | environments, profiles | 1–2 | global context filter (the four A=M themes) |
| `category` (main → sub) | environments, profile interests | 1 primary + up to 4 more | discovery, relevance, analytics |
| `format` | environments | exactly 1 | what kind of gathering it is; drives default policies |
| `purpose` | environments, profile goals | 1–3 | why people come; relevance |
| `audience` | environments (target), profiles (self-declared) | 0–n | desired profiles; relevance and eligibility |
| `experience_level` | environments (minimum/target), profile skills | 0–1 | eligibility (hard) or relevance (soft), set by organiser |
| `location_scope` | environments | exactly 1 | online / local / regional / national / international |
| `interest` | profiles | 0–n | = `category` terms chosen by a person; no separate interest list |

Interests deliberately reuse `category` terms. A person who picks "Technology & AI → Artificial Intelligence" as an interest is then matched against environments that have that same category code. One vocabulary, so no mapping layer is needed.

## 3. Themes (facet `theme`)

The four global themes from the Demo Blueprint, used as context filters across all workspaces.

| Code | Label |
|---|---|
| `theme.city_society` | City & Society |
| `theme.business_capital` | Business & Capital |
| `theme.technology_ai` | Technology & AI |
| `theme.creative_culture` | Creative & Culture |

## 4. Categories (facet `category`, two levels)

| Main category (code) | Subcategories (code suffix) | Default theme |
|---|---|---|
| Business & Entrepreneurship (`business`) | startups, scaleups, sme, sales_marketing, finance_investment, leadership, real_estate, retail_hospitality | Business & Capital |
| Networking & Community (`networking`) | professional_networking, founders, local_business, alumni, cross_sector | Business & Capital |
| Technology & AI (`technology`) | artificial_intelligence, software_development, data, automation, cybersecurity, hardware_robotics | Technology & AI |
| Creative & Media (`creative`) | design, film_video, music, photography, writing_publishing, fashion, content_creation | Creative & Culture |
| Education & Development (`education`) | personal_development, professional_skills, career, mentoring, academic, students | City & Society |
| City & Society (`city`) | urban_development, local_initiatives, sustainability, mobility, public_sector, social_impact | City & Society |
| Social & Culture (`social`) | social_gatherings, culture_heritage, food_drink, arts_events | Creative & Culture |
| Sports & Wellbeing (`sports`) | sports_activities, outdoor, wellbeing | City & Society |
| Projects & Collaboration (`projects`) | co_creation, open_calls, partnerships, volunteering | Business & Capital |
| Ventures & Capital (`ventures`) | investors, fundraising, acquisitions, grants | Business & Capital |

The ten "environment types" from the directive are split over two facets. *Workshop*, *Conference* and *Training* are **formats** (§5); *Business*, *Social*, *Creative*, *Sports* and *Local / City* are **categories**. Keeping them apart lets you search for, for example, "creative workshops" without inventing a "creative workshop" category.

## 5. Formats (facet `format`)

The format sets the environment *kind* (§9) and the default access and capacity settings, which the organiser can change.

| Code | Label | Kind | Default access | Default capacity behaviour |
|---|---|---|---|---|
| `format.network_event` | Network event | EVENT | PUBLIC | open registration, waitlist on |
| `format.meetup` | Meetup | EVENT | PUBLIC | open registration |
| `format.workshop` | Workshop | EVENT | PUBLIC | hard cap, waitlist on, eligibility optional |
| `format.training` | Training | PROGRAM | CURATED | hard cap, eligibility on (level), payment later |
| `format.conference` | Conference | EVENT | PUBLIC | hard cap, waitlist on |
| `format.webinar` | Webinar | EVENT | PUBLIC | soft cap |
| `format.dinner` | Dinner / closed gathering | EVENT | PRIVATE | invite only, no distribution |
| `format.session` | Working / creative session | EVENT | CURATED | hard cap, relevance matching |
| `format.social_hub` | Social hub | HUB | COMMUNITY | membership-based, no fixed cap |
| `format.business_hub` | Business hub | HUB | COMMUNITY | membership-based, manual approval |
| `format.community` | Community | HUB | COMMUNITY | membership-based |
| `format.education_program` | Education programme | PROGRAM | CURATED | cohort cap, eligibility on |
| `format.project_space` | Project & collaboration space | PROJECT_SPACE | PRIVATE | linked to a project's members |

## 6. Purpose (facet `purpose`)

`purpose.connect` · `purpose.learn` · `purpose.collaborate` · `purpose.create` · `purpose.hire` · `purpose.invest` · `purpose.sell_partner` · `purpose.celebrate` · `purpose.give_back`

## 7. Audience (facet `audience`)

These match the profile types from the multi-profile decision ("one account, several profiles"). An environment lists who it is for; a person's profiles say who they are.

`audience.individual` · `audience.professional` · `audience.entrepreneur` · `audience.creator` · `audience.student` · `audience.organization` · `audience.investor` · `audience.recruiter` · `audience.hub_community` · `audience.public_sector`

## 8. Experience level and location scope

- `experience_level`: `level.open` (default) · `level.beginner` · `level.intermediate` · `level.advanced` · `level.expert`. Organisers choose whether the level is a **requirement** (eligibility) or a **target** (relevance only).
- `location_scope`: `scope.online` · `scope.local` · `scope.regional` · `scope.national` · `scope.international`. Physical location itself is a reference to a Location record (see the A=M MAP plan), not a taxonomy term.

## 9. Environment kinds (structural, not taxonomy)

Kinds describe how an environment *behaves*. They are a fixed enum in code, not editable terms.

| Kind | Time model | Participation model | Examples |
|---|---|---|---|
| `EVENT` | one occurrence with start/end | registration per event | network evening, workshop, conference, dinner |
| `PROGRAM` | several sessions over a period | enrolment in a cohort | training, education programme |
| `HUB` | ongoing | membership | social hub, business hub, community |
| `PROJECT_SPACE` | follows the project lifecycle | project membership (existing projects domain) | project & collaboration space |

## 10. Mapping the existing data

| Existing value | Where | Maps to |
|---|---|---|
| `events.event_type = 'Networking'` | DB / `types.ts` | format `network_event` + category `networking` |
| `'Workshop'` | | format `workshop`; category set by organiser (default `education.professional_skills`) |
| `'Conference'` | | format `conference` |
| `'Webinar'` | | format `webinar`, scope `online` |
| `'Meetup'` | | format `meetup` |
| `'Community'` | | format `meetup` + category `networking.cross_sector` |
| `'Business'` | | format `network_event` + category `business` |
| `'Technology'` | | format `meetup` + category `technology` |
| `'Summit'` (API default in `POST /api/events`) | not in the TS union — inconsistency | format `conference` |
| `hubs.type = city / industry / skill / community` | DB | format `social_hub` or `business_hub` + category (`city`, matching industry category, skill niche, `networking`) |
| `events.topics TEXT[]` | DB | kept as organiser tags (`environment_tags`); admins may map frequent tags to central terms |

The backfill is additive: the old columns stay until all readers use the new tables (see the implementation plan, step EI-P1).

## 11. Governance

- **Owner:** A=M platform admin. Organisers cannot create central terms; they can propose them.
- **Versioning:** every change gets a `taxonomy_version`. Matching results and analytics store the version they were computed with.
- **Translations:** `taxonomy_term_labels (code, locale, label)`; English and Dutch at launch.
- **Change review:** retiring or merging a term needs a migration note covering affected environments, profiles and saved filters.

## 12. Data model (PROPOSED)

```
taxonomy_terms
  code TEXT PK            -- 'technology.artificial_intelligence'
  facet TEXT NOT NULL     -- theme | category | format | purpose | audience | experience_level | location_scope
  parent_code TEXT NULL REFERENCES taxonomy_terms(code)   -- subcategory -> main category
  default_theme TEXT NULL REFERENCES taxonomy_terms(code)
  status TEXT NOT NULL DEFAULT 'active'   -- active | retired
  replaced_by TEXT NULL REFERENCES taxonomy_terms(code)
  sort_order INT, version INT NOT NULL, created_at, updated_at
taxonomy_term_labels (code, locale, label, description)  PK (code, locale)
environment_terms (environment_id, term_code, is_primary, role)  -- role: target | requirement
profile_terms (profile_id, term_code, source)                    -- source: self_declared | organiser_added (never inferred)
environment_tags (environment_id, tag)                           -- free organiser tags, display only
```

RLS: `taxonomy_terms` and labels are publicly readable, admin-writable. `profile_terms` follows the profile's visibility settings.

## 13. Acceptance criteria

- [ ] All seed terms load from a migration seed, and codes are unique and stable.
- [ ] Every existing `events.event_type` and `hubs.type` value maps to at least one term (§10), with no unmapped rows after backfill.
- [ ] An organiser cannot save an environment without a primary category and a format.
- [ ] Organiser tags never change eligibility or matching results (unit test).
- [ ] No term exists for a special-category attribute (review checklist).
- [ ] Retiring a term keeps old environments readable and shows the replacement.
