/**
 * Access & Audience Policy — question 3 (access permission) and question 6
 * (approval). Spec: AM_ACCESS_AUDIENCE_POLICY_SPEC.md §2, §3, §5.
 *
 * Pure functions: no database, no clock (callers pass `now`), no I/O.
 * Deny by default: every branch that is not explicitly allowed ends in NONE.
 * Relevance is NOT an input here (spec rule R1).
 */
import type {
  AccessPolicy,
  ActorContext,
  AutoCondition,
  EnvironmentForPolicy,
  ParticipationStatus,
} from '../../domain/environments/types.ts';

export type AccessAction =
  | 'MANAGE' // owner, co-organizer, owning-org admin, platform admin
  | 'CHECK_IN_ONLY' // check-in staff
  | 'OWN_PARTICIPATION' // already participating: show own status / RSVP controls
  | 'REGISTER'
  | 'REQUEST'
  | 'RESPOND_TO_INVITATION'
  | 'NONE';

export type AccessReason =
  | 'ORGANIZER'
  | 'STAFF'
  | 'PARTICIPANT'
  | 'INVITED'
  | 'OPEN_REGISTRATION'
  | 'REQUEST_REQUIRED'
  | 'COMMUNITY_MEMBER'
  | 'NOMINATED_GUEST'
  | 'PARTNER_HUB_MEMBER'
  | 'SIGN_IN_REQUIRED'
  | 'INVITATION_REQUIRED'
  | 'MEMBERS_ONLY'
  | 'REGISTRATION_CLOSED'
  | 'NOT_PUBLISHED'
  | 'NOT_FOUND';

export interface AccessDecision {
  /** false → every endpoint must answer 404, so the environment's existence is not revealed. */
  visible: boolean;
  action: AccessAction;
  reason: AccessReason;
}

/** Statuses that count as "already participating". REMOVED, DECLINED, CANCELLED do not. */
const ACTIVE_PARTICIPATION: ReadonlySet<ParticipationStatus> = new Set<ParticipationStatus>([
  'INVITED',
  'REQUESTED',
  'PENDING_APPROVAL',
  'CONFIRMED',
  'MAYBE',
  'WAITLISTED',
  'CHECKED_IN',
  'NO_RESPONSE',
]);

const hidden: AccessDecision = { visible: false, action: 'NONE', reason: 'NOT_FOUND' };

function intersects(a: readonly string[], b: readonly string[]): boolean {
  if (a.length === 0 || b.length === 0) return false;
  const set = new Set(a);
  return b.some((x) => set.has(x));
}

/** Registration for time-bound environments closes when they start. Hubs never close. */
export function isRegistrationClosed(env: EnvironmentForPolicy, now: Date): boolean {
  if (env.startsAt === null) return false;
  return new Date(env.startsAt).getTime() <= now.getTime();
}

/**
 * Who may see this environment, and what may they do with it?
 * Implements the decision tree of the access spec §3.
 */
export function checkAccess(actor: ActorContext, env: EnvironmentForPolicy, now: Date): AccessDecision {
  const policy = env.policy;
  const signedIn = actor.userId !== null;

  // 1. Organizer side. Organizers see drafts and every status.
  if (actor.isPlatformAdmin || actor.isOwningOrgAdmin || actor.organizerRole === 'OWNER' || actor.organizerRole === 'CO_ORGANIZER') {
    return { visible: true, action: 'MANAGE', reason: 'ORGANIZER' };
  }
  if (actor.organizerRole === 'CHECKIN_STAFF') {
    return { visible: true, action: 'CHECK_IN_ONLY', reason: 'STAFF' };
  }

  const participating = actor.participationStatus !== null && ACTIVE_PARTICIPATION.has(actor.participationStatus);

  // 2. Not published: only people who already take part may still see a cancelled environment.
  if (env.status !== 'PUBLISHED') {
    if (env.status === 'CANCELLED' && participating) {
      return { visible: true, action: 'OWN_PARTICIPATION', reason: 'PARTICIPANT' };
    }
    return hidden;
  }

  // 3. Existing participants manage their own participation (an INVITED participant responds).
  if (participating) {
    if (actor.participationStatus === 'INVITED') {
      return { visible: true, action: 'RESPOND_TO_INVITATION', reason: 'INVITED' };
    }
    return { visible: true, action: 'OWN_PARTICIPATION', reason: 'PARTICIPANT' };
  }

  const closed = isRegistrationClosed(env, now);

  // 4. Open invitation: the invitee may respond regardless of the model.
  if (signedIn && actor.hasOpenInvitation) {
    if (closed) return { visible: true, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
    return { visible: true, action: 'RESPOND_TO_INVITATION', reason: 'INVITED' };
  }

  switch (policy.accessModel) {
    case 'PUBLIC':
      return decideSelfService(policy, signedIn, closed, true);

    case 'PRIVATE':
      // Not discoverable, no self-service. Uninvited actors must not learn it exists.
      return hidden;

    case 'CURATED': {
      if (!policy.discoverable) return hidden;
      if (!signedIn) return { visible: true, action: 'NONE', reason: 'SIGN_IN_REQUIRED' };
      if (closed) return { visible: true, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
      // Curated environments are never open registration: people apply.
      return { visible: true, action: 'REQUEST', reason: 'REQUEST_REQUIRED' };
    }

    case 'COMMUNITY': {
      const isMember = signedIn && intersects(actor.hubIds, policy.communityHubIds);
      const isPartnerMember =
        signedIn && policy.crossCommunity === 'ALLOWED_HUBS' && intersects(actor.hubIds, policy.allowedPartnerHubIds);
      const isGuest = signedIn && policy.guestPolicy === 'MEMBERS_PLUS_N' && actor.isNominatedGuest;

      if (isMember) {
        if (closed) return { visible: true, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
        const d = decideSelfService(policy, true, false, true);
        return d.action === 'NONE' ? d : { ...d, reason: d.action === 'REGISTER' ? 'COMMUNITY_MEMBER' : d.reason };
      }
      if (isGuest) {
        if (closed) return { visible: true, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
        return { visible: true, action: 'REQUEST', reason: 'NOMINATED_GUEST' };
      }
      if (isPartnerMember) {
        if (closed) return { visible: true, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
        return { visible: true, action: 'REQUEST', reason: 'PARTNER_HUB_MEMBER' };
      }
      if (!policy.discoverable) return hidden;
      if (!signedIn) return { visible: true, action: 'NONE', reason: 'SIGN_IN_REQUIRED' };
      return { visible: true, action: 'NONE', reason: 'MEMBERS_ONLY' };
    }

    default:
      return hidden; // unknown model: deny
  }
}

function decideSelfService(policy: AccessPolicy, signedIn: boolean, closed: boolean, visible: boolean): AccessDecision {
  if (!signedIn) return { visible, action: 'NONE', reason: 'SIGN_IN_REQUIRED' };
  if (closed) return { visible, action: 'NONE', reason: 'REGISTRATION_CLOSED' };
  switch (policy.registrationMode) {
    case 'OPEN':
      return { visible, action: 'REGISTER', reason: 'OPEN_REGISTRATION' };
    case 'REQUEST':
      return { visible, action: 'REQUEST', reason: 'REQUEST_REQUIRED' };
    case 'INVITE_ONLY':
    default:
      return { visible, action: 'NONE', reason: 'INVITATION_REQUIRED' };
  }
}

// ---------------------------------------------------------------------------
// Question 6 — approval
// ---------------------------------------------------------------------------

/** How the person arrived at the point of joining. */
export type ParticipationPath =
  | 'SELF_REGISTRATION'
  | 'REQUEST'
  | 'GUEST'
  | 'CROSS_COMMUNITY'
  | 'PERSONAL_INVITATION_ACCEPTANCE'
  | 'DISTRIBUTION_INVITATION_ACCEPTANCE'
  | 'WAITLIST_PROMOTION'
  | 'ORGANIZER_ADDED';

export type ApprovalRequirement =
  /** May proceed straight to the capacity check. */
  | 'NONE'
  /** Becomes PENDING_APPROVAL; an organizer decides. */
  | 'ORGANIZER'
  /** Not possible on this path: only a personal invitation admits people. */
  | 'INVITATION';

export interface AutoConditionFacts {
  /** Hubs the person belongs to. */
  hubIds: string[];
  /** Audience codes of the profile context used. */
  audienceCodes: string[];
}

export interface ApprovalDecision {
  required: ApprovalRequirement;
  /** For AUTO_WITHIN_CONDITIONS: which conditions failed (empty when all hold). */
  unmetConditions: AutoCondition['type'][];
}

/** Evaluates every auto condition; returns the ones that do NOT hold. */
export function unmetAutoConditions(
  conditions: readonly AutoCondition[],
  facts: AutoConditionFacts,
  env: EnvironmentForPolicy,
  now: Date,
): AutoCondition['type'][] {
  const unmet: AutoCondition['type'][] = [];
  for (const c of conditions) {
    switch (c.type) {
      case 'hub_membership':
        if (!intersects(facts.hubIds, c.hubIds)) unmet.push(c.type);
        break;
      case 'profile_type':
        if (!intersects(facts.audienceCodes, c.audienceCodes)) unmet.push(c.type);
        break;
      case 'closes_hours_before_start': {
        if (env.startsAt !== null) {
          const cutoff = new Date(env.startsAt).getTime() - c.hours * 3_600_000;
          if (now.getTime() >= cutoff) unmet.push(c.type);
        }
        break;
      }
      default:
        // Unknown condition: fail closed.
        unmet.push((c as AutoCondition).type);
    }
  }
  return unmet;
}

/**
 * Who has to approve this participation? Called only after checkAccess
 * allowed the path and checkEligibility passed.
 *
 * `distributionRequiresApproval` comes from the distribution policy:
 * MANUAL_APPROVAL → true (capacity spec §5.2).
 */
export function approvalRequirement(
  env: EnvironmentForPolicy,
  path: ParticipationPath,
  facts: AutoConditionFacts,
  now: Date,
  distributionRequiresApproval = false,
): ApprovalDecision {
  const none: ApprovalDecision = { required: 'NONE', unmetConditions: [] };
  const organizer: ApprovalDecision = { required: 'ORGANIZER', unmetConditions: [] };

  switch (path) {
    case 'ORGANIZER_ADDED':
    case 'PERSONAL_INVITATION_ACCEPTANCE':
      // The organizer's own action (adding, personally inviting) is the approval.
      return none;
    case 'WAITLIST_PROMOTION':
      // Waitlisted people already passed approval when they joined; they were only short of room.
      return none;
    case 'DISTRIBUTION_INVITATION_ACCEPTANCE':
      return distributionRequiresApproval ? organizer : none;
    case 'CROSS_COMMUNITY':
      // Members of other hubs always need an organizer decision.
      return organizer;
    case 'SELF_REGISTRATION':
    case 'REQUEST':
    case 'GUEST':
      break;
    default:
      return organizer; // unknown path: fail safe
  }

  switch (env.policy.approvalMode) {
    case 'INVITATION_ONLY':
      return { required: 'INVITATION', unmetConditions: [] };
    case 'MANUAL':
      return organizer;
    case 'AUTO_WITHIN_CONDITIONS': {
      const unmet = unmetAutoConditions(env.policy.autoConditions, facts, env, now);
      return unmet.length === 0 ? none : { required: 'ORGANIZER', unmetConditions: unmet };
    }
    default:
      return organizer;
  }
}
