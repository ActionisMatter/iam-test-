/**
 * Eligibility Engine — question 2: does the person meet the organizer's
 * admission requirements? Spec: AM_ACCESS_AUDIENCE_POLICY_SPEC.md §4.
 *
 * Pure. Rules are a closed set; `parseEligibilityRules` rejects anything
 * else, including rule types that would use special-category data.
 */
import type { EligibilityRule, ExperienceLevel, ProfileContext } from '../../domain/environments/types.ts';

export interface UnmetRule {
  type: EligibilityRule['type'];
  /** Plain-language explanation, shown to the person. Never silent. */
  message: string;
}

export interface EligibilityResult {
  eligible: boolean;
  unmet: UnmetRule[];
}

export const LEVEL_ORDER: readonly ExperienceLevel[] = [
  'level.open',
  'level.beginner',
  'level.intermediate',
  'level.advanced',
  'level.expert',
];

const LEVEL_LABEL: Record<ExperienceLevel, string> = {
  'level.open': 'any level',
  'level.beginner': 'beginner',
  'level.intermediate': 'intermediate',
  'level.advanced': 'advanced',
  'level.expert': 'expert',
};

function levelRank(level: ExperienceLevel): number {
  const i = LEVEL_ORDER.indexOf(level);
  return i < 0 ? -1 : i;
}

function intersects(a: readonly string[], b: readonly string[]): boolean {
  const set = new Set(a);
  return b.some((x) => set.has(x));
}

export function checkEligibility(
  profile: ProfileContext,
  rules: readonly EligibilityRule[],
  now: Date,
): EligibilityResult {
  const unmet: UnmetRule[] = [];

  for (const rule of rules) {
    switch (rule.type) {
      case 'required_skill': {
        const skill = profile.skills.find((s) => s.skillId === rule.skillId);
        if (!skill) {
          unmet.push({ type: rule.type, message: `Requires the skill ${rule.label}.` });
        } else if (rule.mustBeVerified && !skill.verified) {
          unmet.push({ type: rule.type, message: `Requires a verified ${rule.label} skill.` });
        }
        break;
      }
      case 'min_experience_level': {
        const required = levelRank(rule.level);
        const candidates = rule.skillId ? profile.skills.filter((s) => s.skillId === rule.skillId) : profile.skills;
        const best = candidates.reduce((max, s) => Math.max(max, levelRank(s.level)), -1);
        if (required > 0 && best < required) {
          unmet.push({ type: rule.type, message: `Requires at least ${LEVEL_LABEL[rule.level]} level.` });
        }
        break;
      }
      case 'profile_type':
        if (!intersects(profile.audienceCodes, rule.audienceCodes)) {
          unmet.push({ type: rule.type, message: 'This environment is for a different profile type.' });
        }
        break;
      case 'hub_membership':
        if (!intersects(profile.hubIds, rule.hubIds)) {
          unmet.push({ type: rule.type, message: `Requires membership of ${rule.label}.` });
        }
        break;
      case 'organization_membership':
        if (!intersects(profile.organizationIds, rule.organizationIds)) {
          unmet.push({ type: rule.type, message: `Requires membership of ${rule.label}.` });
        }
        break;
      case 'location':
        if (!profile.countryCode || !rule.countryCodes.includes(profile.countryCode)) {
          unmet.push({ type: rule.type, message: 'Only open to people in the listed countries.' });
        }
        break;
      case 'prerequisite_environment':
        if (!profile.completedEnvironmentIds.includes(rule.environmentId)) {
          unmet.push({ type: rule.type, message: `Complete ${rule.label} first.` });
        }
        break;
      case 'age_minimum': {
        if (profile.birthYear === null) {
          unmet.push({ type: rule.type, message: `Confirm that you are ${rule.years} or older.` });
        } else {
          // Birth year only (data minimisation): the youngest possible age must already meet the minimum.
          const youngestPossibleAge = now.getUTCFullYear() - profile.birthYear - 1;
          if (youngestPossibleAge < rule.years) {
            unmet.push({ type: rule.type, message: `Only open to people aged ${rule.years} or older.` });
          }
        }
        break;
      }
      default:
        // Unknown rule: fail closed rather than silently admit.
        unmet.push({ type: (rule as EligibilityRule).type, message: 'This environment has a requirement that cannot be checked.' });
    }
  }

  return { eligible: unmet.length === 0, unmet };
}

// ---------------------------------------------------------------------------
// Validation of stored / submitted rules (JSONB → typed rules)
// ---------------------------------------------------------------------------

const ALLOWED_TYPES: ReadonlySet<string> = new Set([
  'required_skill',
  'min_experience_level',
  'profile_type',
  'hub_membership',
  'organization_membership',
  'location',
  'prerequisite_environment',
  'age_minimum',
]);

export interface RuleParseResult {
  rules: EligibilityRule[];
  errors: string[];
}

const isStringArray = (v: unknown): v is string[] => Array.isArray(v) && v.length > 0 && v.every((x) => typeof x === 'string');
const isNonEmptyString = (v: unknown): v is string => typeof v === 'string' && v.trim().length > 0;

/**
 * Turns untrusted JSON into rules. Any unknown or malformed rule is an
 * error: an organizer cannot invent rule types (e.g. on health or religion).
 */
export function parseEligibilityRules(input: unknown): RuleParseResult {
  const errors: string[] = [];
  const rules: EligibilityRule[] = [];
  if (!Array.isArray(input)) return { rules, errors: ['Eligibility rules must be a list.'] };

  input.forEach((raw, i) => {
    const r = raw as Record<string, unknown> | null;
    const at = `rule ${i + 1}`;
    if (!r || typeof r !== 'object' || typeof r.type !== 'string' || !ALLOWED_TYPES.has(r.type)) {
      errors.push(`${at}: unsupported rule type.`);
      return;
    }
    switch (r.type) {
      case 'required_skill':
        if (isNonEmptyString(r.skillId) && isNonEmptyString(r.label) && typeof r.mustBeVerified === 'boolean') {
          rules.push({ type: 'required_skill', skillId: r.skillId, label: r.label, mustBeVerified: r.mustBeVerified });
        } else errors.push(`${at}: required_skill needs skillId, label and mustBeVerified.`);
        break;
      case 'min_experience_level':
        if (typeof r.level === 'string' && (LEVEL_ORDER as readonly string[]).includes(r.level) && (r.skillId === undefined || isNonEmptyString(r.skillId))) {
          rules.push({ type: 'min_experience_level', level: r.level as ExperienceLevel, ...(r.skillId ? { skillId: r.skillId as string } : {}) });
        } else errors.push(`${at}: min_experience_level needs a valid level.`);
        break;
      case 'profile_type':
        if (isStringArray(r.audienceCodes) && r.audienceCodes.every((c) => c.startsWith('audience.'))) {
          rules.push({ type: 'profile_type', audienceCodes: r.audienceCodes });
        } else errors.push(`${at}: profile_type needs audience codes.`);
        break;
      case 'hub_membership':
        if (isStringArray(r.hubIds) && isNonEmptyString(r.label)) rules.push({ type: 'hub_membership', hubIds: r.hubIds, label: r.label });
        else errors.push(`${at}: hub_membership needs hubIds and label.`);
        break;
      case 'organization_membership':
        if (isStringArray(r.organizationIds) && isNonEmptyString(r.label)) {
          rules.push({ type: 'organization_membership', organizationIds: r.organizationIds, label: r.label });
        } else errors.push(`${at}: organization_membership needs organizationIds and label.`);
        break;
      case 'location':
        if (isStringArray(r.countryCodes) && r.countryCodes.every((c) => /^[A-Z]{2,3}$/.test(c))) {
          rules.push({ type: 'location', countryCodes: r.countryCodes });
        } else errors.push(`${at}: location needs ISO country codes.`);
        break;
      case 'prerequisite_environment':
        if (isNonEmptyString(r.environmentId) && isNonEmptyString(r.label)) {
          rules.push({ type: 'prerequisite_environment', environmentId: r.environmentId, label: r.label });
        } else errors.push(`${at}: prerequisite_environment needs environmentId and label.`);
        break;
      case 'age_minimum':
        if (typeof r.years === 'number' && Number.isInteger(r.years) && r.years >= 16 && r.years <= 21) {
          rules.push({ type: 'age_minimum', years: r.years });
        } else errors.push(`${at}: age_minimum must be a whole number between 16 and 21 (legal minimums only).`);
        break;
    }
  });

  return { rules, errors };
}
