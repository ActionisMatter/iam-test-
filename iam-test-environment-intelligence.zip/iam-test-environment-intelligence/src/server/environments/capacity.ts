/**
 * Capacity rules — question 4, pure part.
 * Spec: AM_CAPACITY_DISTRIBUTION_SPEC.md §2–§4.
 *
 * The authoritative capacity decision happens inside the Postgres function
 * `environment_reserve_place` under a row lock (rule C6). `decideReservation`
 * here is the same rule in TypeScript: it documents the logic the SQL must
 * implement and lets it be unit-tested. It must never be used on cached
 * counts to admit someone.
 */
import type { ParticipationStatus } from '../../domain/environments/types.ts';

/** C1: only these consume a place. */
export const CONSUMING_STATUSES: ReadonlySet<ParticipationStatus> = new Set<ParticipationStatus>(['CONFIRMED', 'CHECKED_IN']);

/** A person in one of these is already in the process; a second registration is a no-op (C5, idempotency). */
export const ACTIVE_STATUSES: ReadonlySet<ParticipationStatus> = new Set<ParticipationStatus>([
  'CONFIRMED',
  'CHECKED_IN',
  'WAITLISTED',
  'REQUESTED',
  'PENDING_APPROVAL',
]);

export interface Hold {
  expiresAt: string;
}

export interface CapacityInput {
  /** null = no limit (e.g. an ongoing hub). */
  capacity: number | null;
  participants: ReadonlyArray<{ status: ParticipationStatus }>;
  /** MAYBE holds or (later) payment holds. Only unexpired holds count (C3, C9). */
  holds: readonly Hold[];
  now: Date;
}

export interface CapacitySnapshot {
  capacity: number | null;
  confirmed: number;
  checkedIn: number;
  activeHolds: number;
  /** null when there is no limit. Never negative. */
  available: number | null;
  /** C8: how far confirmed + holds exceed a reduced capacity (0 when not over). */
  overCapacityBy: number;
  waitlisted: number;
  maybe: number;
  invited: number;
  noResponse: number;
  declined: number;
  cancelled: number;
  pendingApproval: number;
  /** confirmed / capacity, 0–1+; null without a limit. */
  utilisation: number | null;
  canConfirm: boolean;
}

export function computeCapacity(input: CapacityInput): CapacitySnapshot {
  const count = (s: ParticipationStatus) => input.participants.filter((p) => p.status === s).length;
  const confirmed = input.participants.filter((p) => CONSUMING_STATUSES.has(p.status)).length;
  const nowMs = input.now.getTime();
  const activeHolds = input.holds.filter((h) => new Date(h.expiresAt).getTime() > nowMs).length;

  let available: number | null = null;
  let overCapacityBy = 0;
  let utilisation: number | null = null;
  if (input.capacity !== null) {
    const used = confirmed + activeHolds;
    available = Math.max(0, input.capacity - used);
    overCapacityBy = Math.max(0, used - input.capacity);
    utilisation = input.capacity > 0 ? confirmed / input.capacity : null;
  }

  return {
    capacity: input.capacity,
    confirmed,
    checkedIn: count('CHECKED_IN'),
    activeHolds,
    available,
    overCapacityBy,
    waitlisted: count('WAITLISTED'),
    maybe: count('MAYBE'),
    invited: count('INVITED'),
    noResponse: count('NO_RESPONSE'),
    declined: count('DECLINED'),
    cancelled: count('CANCELLED'),
    pendingApproval: count('PENDING_APPROVAL') + count('REQUESTED'),
    utilisation,
    canConfirm: available === null || available > 0,
  };
}

export type ReservationOutcome = 'CONFIRMED' | 'WAITLISTED' | 'ALREADY_PARTICIPATING';

/**
 * C5/C6 in pure form. `confirmedCount` and `activeHolds` must be read inside
 * the same transaction that holds the environment row lock.
 */
export function decideReservation(input: {
  capacity: number | null;
  confirmedCount: number;
  activeHolds: number;
  existingStatus: ParticipationStatus | null;
}): ReservationOutcome {
  if (input.existingStatus !== null && ACTIVE_STATUSES.has(input.existingStatus)) return 'ALREADY_PARTICIPATING';
  if (input.capacity === null) return 'CONFIRMED';
  return input.confirmedCount + input.activeHolds < input.capacity ? 'CONFIRMED' : 'WAITLISTED';
}

// ---------------------------------------------------------------------------
// Status transitions
// ---------------------------------------------------------------------------

export type TransitionActor = 'PARTICIPANT' | 'ORGANIZER' | 'CHECKIN_STAFF' | 'SYSTEM';

type TransitionTable = Record<TransitionActor, Partial<Record<ParticipationStatus, readonly ParticipationStatus[]>>>;

/**
 * Who may move a participation from which status to which.
 * - Becoming CONFIRMED or WAITLISTED is only ever the result of the
 *   reservation function (SYSTEM), so capacity is always checked.
 * - SYSTEM never sets DECLINED: NO_RESPONSE is not a decline (C10).
 * - An invitation never jumps straight to CONFIRMED without the reservation step (R2).
 */
const TRANSITIONS: TransitionTable = {
  PARTICIPANT: {
    INVITED: ['MAYBE', 'DECLINED'],
    NO_RESPONSE: ['MAYBE', 'DECLINED'],
    MAYBE: ['DECLINED'],
    CONFIRMED: ['CANCELLED'],
    WAITLISTED: ['CANCELLED'],
    REQUESTED: ['CANCELLED'],
    PENDING_APPROVAL: ['CANCELLED'],
  },
  ORGANIZER: {
    REQUESTED: ['DECLINED', 'REMOVED'],
    PENDING_APPROVAL: ['DECLINED', 'REMOVED'],
    CONFIRMED: ['CHECKED_IN', 'REMOVED'],
    WAITLISTED: ['REMOVED'],
    INVITED: ['REMOVED'],
    MAYBE: ['REMOVED'],
    NO_RESPONSE: ['REMOVED'],
    CHECKED_IN: ['CONFIRMED'], // undo an accidental check-in
  },
  CHECKIN_STAFF: {
    CONFIRMED: ['CHECKED_IN'],
  },
  SYSTEM: {
    // Results of the reservation function (after access, eligibility and approval passed):
    INVITED: ['CONFIRMED', 'WAITLISTED', 'NO_RESPONSE'],
    NO_RESPONSE: ['CONFIRMED', 'WAITLISTED'],
    MAYBE: ['CONFIRMED', 'WAITLISTED'],
    REQUESTED: ['PENDING_APPROVAL', 'CONFIRMED', 'WAITLISTED'],
    PENDING_APPROVAL: ['CONFIRMED', 'WAITLISTED'],
    WAITLISTED: ['CONFIRMED'],
    CANCELLED: ['CONFIRMED', 'WAITLISTED'],
    DECLINED: ['CONFIRMED', 'WAITLISTED'],
  },
};

export function canTransition(from: ParticipationStatus, to: ParticipationStatus, actor: TransitionActor): boolean {
  return TRANSITIONS[actor][from]?.includes(to) ?? false;
}

/** Does this transition free a place? (C2) */
export function releasesPlace(from: ParticipationStatus, to: ParticipationStatus): boolean {
  return CONSUMING_STATUSES.has(from) && !CONSUMING_STATUSES.has(to);
}

// ---------------------------------------------------------------------------
// Waitlist
// ---------------------------------------------------------------------------

export interface WaitlistEntry {
  participantId: string;
  position: number;
  /** Re-checked at promotion time: requirements may have changed. */
  eligible: boolean;
}

/** First eligible person by position; ties broken by id for determinism. */
export function nextForPromotion(entries: readonly WaitlistEntry[]): WaitlistEntry | null {
  const sorted = [...entries].sort((a, b) => a.position - b.position || a.participantId.localeCompare(b.participantId));
  return sorted.find((e) => e.eligible) ?? null;
}

// ---------------------------------------------------------------------------
// Rates (spec §2, derived metrics)
// ---------------------------------------------------------------------------

/** checked-in / confirmed, after the event. null when nobody was confirmed. */
export function attendanceRate(checkedIn: number, confirmedIncludingCheckedIn: number): number | null {
  return confirmedIncludingCheckedIn > 0 ? checkedIn / confirmedIncludingCheckedIn : null;
}

/** Places re-filled from waitlist or distribution after a cancellation / cancellations. */
export function replacementRate(refilledAfterCancellation: number, cancellations: number): number | null {
  return cancellations > 0 ? Math.min(1, refilledAfterCancellation / cancellations) : null;
}
