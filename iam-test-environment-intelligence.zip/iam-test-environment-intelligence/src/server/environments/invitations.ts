/**
 * Invitation permission — question 5: may this person be invited?
 * Spec: AM_ACCESS_AUDIENCE_POLICY_SPEC.md §6.
 *
 * Pure. Must be evaluated at preview time AND again at send time, because
 * preferences and suppressions can change in between.
 */
import type { InvitationChannel, InvitationKind } from '../../domain/environments/types.ts';

export type Inviter = 'ORGANIZER' | 'PLATFORM_ADMIN' | 'HUB_ADMIN' | 'PARTICIPANT_GUEST' | 'DISTRIBUTION_ENGINE';

export interface InvitationPreference {
  /** null = applies to every profile context of the user. */
  profileContextId: string | null;
  kind: InvitationKind;
  /** null = every category. Otherwise taxonomy category codes (main or sub). */
  categoryCodes: string[] | null;
  channel: InvitationChannel;
  /** Only meaningful for DISTRIBUTION_SUGGESTION. Default false. */
  allowSuggestToOrganizers: boolean;
}

export interface Suppression {
  scope: 'GLOBAL' | 'ORGANIZATION' | 'ENVIRONMENT';
  scopeId: string | null;
}

export interface CanInviteInput {
  inviter: Inviter;
  kind: InvitationKind;
  environmentId: string;
  environmentOrganizationId: string | null;
  environmentCategoryCodes: string[];
  recipientProfileContextId: string | null;
  preferences: readonly InvitationPreference[];
  suppressions: readonly Suppression[];
  hasOpenInvitation: boolean;
  recipientIsParticipating: boolean;
  /** Distribution invitations this recipient received in the last 7 days, across all organizers. */
  distributionInvitationsLast7Days: number;
  weeklyDistributionCap: number;
  /** Guest invitations: how many guests this member already invited, and the policy limit. */
  guestsAlreadyInvited?: number;
  guestsPerMember?: number | null;
}

export type CanInviteReason =
  | 'ALLOWED'
  | 'ENGINE_CANNOT_INVITE'
  | 'INVITER_NOT_PERMITTED_FOR_KIND'
  | 'DUPLICATE_OPEN_INVITATION'
  | 'ALREADY_PARTICIPATING'
  | 'SUPPRESSED'
  | 'NO_PREFERENCE'
  | 'OPTED_OUT'
  | 'NOT_OPTED_IN_TO_SUGGESTIONS'
  | 'CATEGORY_NOT_WANTED'
  | 'FREQUENCY_CAP'
  | 'GUEST_LIMIT';

export interface CanInviteResult {
  allowed: boolean;
  channel: InvitationChannel;
  reason: CanInviteReason;
}

const KINDS_BY_INVITER: Record<Inviter, readonly InvitationKind[]> = {
  ORGANIZER: ['PERSONAL', 'DISTRIBUTION_SUGGESTION', 'ORGANIZATION'],
  PLATFORM_ADMIN: ['PERSONAL', 'DISTRIBUTION_SUGGESTION', 'ORGANIZATION'],
  HUB_ADMIN: ['HUB'],
  PARTICIPANT_GUEST: ['PERSONAL'],
  DISTRIBUTION_ENGINE: [],
};

const deny = (reason: CanInviteReason): CanInviteResult => ({ allowed: false, channel: 'NONE', reason });

const mainOf = (c: string) => (c.includes('.') ? c.slice(0, c.indexOf('.')) : c);

function categoryWanted(wanted: string[] | null, envCodes: readonly string[]): boolean {
  if (wanted === null) return true;
  return envCodes.some((code) => wanted.includes(code) || wanted.includes(mainOf(code)));
}

/** Most specific preference wins: one for this profile context beats a global one. */
function findPreference(
  prefs: readonly InvitationPreference[],
  kind: InvitationKind,
  contextId: string | null,
): InvitationPreference | null {
  const forKind = prefs.filter((p) => p.kind === kind);
  return (
    (contextId !== null ? forKind.find((p) => p.profileContextId === contextId) : undefined) ??
    forKind.find((p) => p.profileContextId === null) ??
    null
  );
}

export function canInvite(input: CanInviteInput): CanInviteResult {
  // The distribution engine only proposes; a human approves and the organizer is the inviter.
  if (input.inviter === 'DISTRIBUTION_ENGINE') return deny('ENGINE_CANNOT_INVITE');
  if (!KINDS_BY_INVITER[input.inviter].includes(input.kind)) return deny('INVITER_NOT_PERMITTED_FOR_KIND');
  if (input.hasOpenInvitation) return deny('DUPLICATE_OPEN_INVITATION');
  if (input.recipientIsParticipating) return deny('ALREADY_PARTICIPATING');

  const suppressed = input.suppressions.some(
    (s) =>
      s.scope === 'GLOBAL' ||
      (s.scope === 'ORGANIZATION' && s.scopeId !== null && s.scopeId === input.environmentOrganizationId) ||
      (s.scope === 'ENVIRONMENT' && s.scopeId === input.environmentId),
  );
  if (suppressed) return deny('SUPPRESSED');

  if (input.inviter === 'PARTICIPANT_GUEST') {
    const limit = input.guestsPerMember ?? 0;
    if ((input.guestsAlreadyInvited ?? 0) >= limit) return deny('GUEST_LIMIT');
  }

  const pref = findPreference(input.preferences, input.kind, input.recipientProfileContextId);

  if (input.kind === 'DISTRIBUTION_SUGGESTION') {
    // Never without an explicit opt-in.
    if (!pref || !pref.allowSuggestToOrganizers) return deny('NOT_OPTED_IN_TO_SUGGESTIONS');
    if (input.distributionInvitationsLast7Days >= input.weeklyDistributionCap) return deny('FREQUENCY_CAP');
  }

  if (!pref) {
    // Personal invitations default to in-app only; every other kind needs an explicit preference.
    if (input.kind === 'PERSONAL') return { allowed: true, channel: 'IN_APP', reason: 'ALLOWED' };
    return deny('NO_PREFERENCE');
  }
  if (pref.channel === 'NONE') return deny('OPTED_OUT');
  if (!categoryWanted(pref.categoryCodes, input.environmentCategoryCodes)) return deny('CATEGORY_NOT_WANTED');

  return { allowed: true, channel: pref.channel, reason: 'ALLOWED' };
}
