/**
 * Audience Matching — question 1: does this person fit this environment?
 * Spec: AM_ENVIRONMENT_INTELLIGENCE_SPEC.md §3 and §8.
 *
 * Relevance only ranks suggestions. It never grants or blocks anything (R1).
 * Output is a level plus reasons; no numeric score leaves this module (D-11).
 * Inputs are declared profile data only: the ProfileContext type has no
 * behavioural fields, so non-response or inactivity cannot lower relevance (R6).
 */
import type { EnvironmentAudienceProfile, ProfileContext } from '../../domain/environments/types.ts';

export type RelevanceLevel = 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';

export type RelevanceReason =
  | { kind: 'shared_interest'; codes: string[] }
  | { kind: 'related_interest'; codes: string[] }
  | { kind: 'audience_match'; codes: string[] }
  | { kind: 'purpose_match'; codes: string[] }
  | { kind: 'skill_match'; skillIds: string[] }
  | { kind: 'hub_member'; hubIds: string[] }
  | { kind: 'same_city'; city: string }
  | { kind: 'same_country'; countryCode: string };

export interface RelevanceAssessment {
  level: RelevanceLevel;
  reasons: RelevanceReason[];
}

/** 'technology.artificial_intelligence' → 'technology'. Main categories return themselves. */
export function mainCategoryOf(code: string): string {
  const dot = code.indexOf('.');
  return dot < 0 ? code : code.slice(0, dot);
}

function overlap(a: readonly string[], b: readonly string[]): string[] {
  const set = new Set(b);
  return [...new Set(a)].filter((x) => set.has(x)).sort();
}

const norm = (s: string | null): string => (s ?? '').trim().toLowerCase();

// Internal weights. Kept private on purpose: callers only ever see levels and reasons.
const W = {
  sharedInterest: 3,
  relatedInterest: 1,
  audience: 2,
  purpose: 1,
  skill: 2,
  hub: 2,
  city: 2,
  country: 1,
} as const;
const HIGH_AT = 7;
const MEDIUM_AT = 4;

export function assessRelevance(profile: ProfileContext, env: EnvironmentAudienceProfile): RelevanceAssessment {
  const reasons: RelevanceReason[] = [];
  let points = 0;

  // Interests vs environment categories: exact code first, then same main category.
  const shared = overlap(profile.interestCodes, env.categoryCodes);
  if (shared.length > 0) {
    reasons.push({ kind: 'shared_interest', codes: shared });
    points += W.sharedInterest * Math.min(shared.length, 2);
  }
  const envMains = env.categoryCodes.filter((c) => !shared.includes(c)).map(mainCategoryOf);
  const related = overlap(
    profile.interestCodes.filter((c) => !shared.includes(c)).map(mainCategoryOf),
    envMains,
  );
  if (related.length > 0) {
    reasons.push({ kind: 'related_interest', codes: related });
    points += W.relatedInterest * Math.min(related.length, 2);
  }

  const audience = overlap(profile.audienceCodes, env.audienceCodes);
  if (audience.length > 0) {
    reasons.push({ kind: 'audience_match', codes: audience });
    points += W.audience;
  }

  const purposes = overlap(profile.purposeCodes, env.purposeCodes);
  if (purposes.length > 0) {
    reasons.push({ kind: 'purpose_match', codes: purposes });
    points += W.purpose;
  }

  const skills = overlap(
    profile.skills.map((s) => s.skillId),
    env.targetSkillIds,
  );
  if (skills.length > 0) {
    reasons.push({ kind: 'skill_match', skillIds: skills });
    points += W.skill * Math.min(skills.length, 2);
  }

  const hubs = overlap(profile.hubIds, env.communityHubIds);
  if (hubs.length > 0) {
    reasons.push({ kind: 'hub_member', hubIds: hubs });
    points += W.hub;
  }

  // Location only matters for physical environments.
  if (env.locationScope !== 'scope.online') {
    if (env.city && norm(profile.city) !== '' && norm(profile.city) === norm(env.city)) {
      reasons.push({ kind: 'same_city', city: env.city });
      points += W.city;
    } else if (env.countryCode && profile.countryCode === env.countryCode) {
      reasons.push({ kind: 'same_country', countryCode: env.countryCode });
      points += W.country;
    }
  }

  const level: RelevanceLevel =
    points >= HIGH_AT ? 'HIGH' : points >= MEDIUM_AT ? 'MEDIUM' : points > 0 ? 'LOW' : 'NONE';
  return { level, reasons };
}

const LEVEL_RANK: Record<RelevanceLevel, number> = { HIGH: 3, MEDIUM: 2, LOW: 1, NONE: 0 };

/** Stable ordering for suggestion lists: level first, then number of reasons, then id. */
export function compareRelevance(
  a: { id: string; assessment: RelevanceAssessment },
  b: { id: string; assessment: RelevanceAssessment },
): number {
  return (
    LEVEL_RANK[b.assessment.level] - LEVEL_RANK[a.assessment.level] ||
    b.assessment.reasons.length - a.assessment.reasons.length ||
    a.id.localeCompare(b.id)
  );
}
