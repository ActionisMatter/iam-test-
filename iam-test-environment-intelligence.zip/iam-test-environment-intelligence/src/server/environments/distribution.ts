/**
 * Capacity triggers and distribution proposals ("Fill available spots").
 * Spec: AM_CAPACITY_DISTRIBUTION_SPEC.md §5–§7.
 *
 * Pure. A trigger never sends anything: the strongest outcome is
 * CREATE_PROPOSAL, which an organizer must approve.
 */
import type { DistributionPolicy, TriggerDefinition } from '../../domain/environments/types.ts';
import type { RelevanceAssessment } from './relevance.ts';
import type { CanInviteResult } from './invitations.ts';
import { compareRelevance } from './relevance.ts';

export interface TriggerSnapshot {
  capacity: number | null;
  available: number | null;
  /** confirmed / capacity, 0–1+. */
  utilisation: number | null;
  waitlisted: number;
  /** Cancellations since the last distribution run (the caller resets it after a run). */
  cancellationsSinceLastRun: number;
}

export type TriggerAction = 'CREATE_PROPOSAL' | 'PROMOTE_WAITLIST' | 'NOTIFY_ORGANIZER';

export interface TriggerFiring {
  trigger: TriggerDefinition['type'];
  /** Idempotency key: the caller stores it and passes it back in `alreadyFired`. */
  key: string;
  action: TriggerAction;
  note: string;
}

export interface EvaluateTriggersInput {
  policy: DistributionPolicy;
  previous: TriggerSnapshot | null;
  current: TriggerSnapshot;
  startsAt: string | null;
  now: Date;
  /** Keys of one-shot triggers that already fired for this environment. */
  alreadyFired: readonly string[];
}

/**
 * Evaluates every configured trigger. Rules:
 * - an opened place goes to the waitlist first (PROMOTE_WAITLIST);
 * - no proposals when mode is NONE, after start, or within minHoursBeforeStart (NOTIFY_ORGANIZER instead);
 * - one-shot triggers (UTILISATION_BELOW) fire once per key.
 */
export function evaluateTriggers(input: EvaluateTriggersInput): TriggerFiring[] {
  const { policy, previous, current, now } = input;
  const fired: TriggerFiring[] = [];
  const startMs = input.startsAt ? new Date(input.startsAt).getTime() : null;
  const hoursToStart = startMs === null ? Infinity : (startMs - now.getTime()) / 3_600_000;

  const proposalAllowed = policy.mode !== 'NONE' && hoursToStart > policy.minHoursBeforeStart;
  const hasOpenPlaces = current.available === null || current.available > 0;

  const resolveAction = (): TriggerAction => {
    if (current.waitlisted > 0 && hasOpenPlaces) return 'PROMOTE_WAITLIST';
    if (!proposalAllowed || !hasOpenPlaces) return 'NOTIFY_ORGANIZER';
    return 'CREATE_PROPOSAL';
  };

  for (const t of policy.triggers) {
    switch (t.type) {
      case 'AVAILABLE_BELOW': {
        // Fires on the crossing only (was above N, now at or below N). See open decision E-14 on intent.
        if (
          previous !== null &&
          previous.available !== null &&
          current.available !== null &&
          previous.available > t.places &&
          current.available <= t.places
        ) {
          fired.push({ trigger: t.type, key: `${t.type}:${t.places}:${current.available}`, action: resolveAction(), note: `Available places dropped to ${current.available}.` });
        }
        break;
      }
      case 'UTILISATION_BELOW': {
        const key = `${t.type}:${t.percent}:${t.checkAtHoursBeforeStart}`;
        if (input.alreadyFired.includes(key) || current.utilisation === null || startMs === null) break;
        if (hoursToStart <= t.checkAtHoursBeforeStart && hoursToStart > 0 && current.utilisation * 100 < t.percent) {
          fired.push({ trigger: t.type, key, action: resolveAction(), note: `Utilisation ${Math.round(current.utilisation * 100)}% is under ${t.percent}%.` });
        }
        break;
      }
      case 'CANCELLATION':
        if (current.cancellationsSinceLastRun >= Math.max(1, t.minCount)) {
          fired.push({ trigger: t.type, key: `${t.type}:${current.cancellationsSinceLastRun}`, action: resolveAction(), note: `${current.cancellationsSinceLastRun} cancellation(s) since the last run.` });
        }
        break;
      case 'WAITLIST_ACTIVATED':
        if (
          previous !== null &&
          previous.available !== null &&
          current.available !== null &&
          previous.available <= 0 &&
          current.available > 0 &&
          current.waitlisted > 0
        ) {
          fired.push({ trigger: t.type, key: `${t.type}:${current.available}`, action: 'PROMOTE_WAITLIST', note: 'A place opened while people are waiting.' });
        }
        break;
      case 'CAPACITY_INCREASED':
        if (previous !== null && previous.capacity !== null && current.capacity !== null && current.capacity > previous.capacity) {
          fired.push({ trigger: t.type, key: `${t.type}:${current.capacity}`, action: resolveAction(), note: `Capacity raised from ${previous.capacity} to ${current.capacity}.` });
        }
        break;
    }
  }
  return fired;
}

// ---------------------------------------------------------------------------
// Candidate list for a proposal
// ---------------------------------------------------------------------------

export interface PersonCandidateInput {
  id: string;
  assessment: RelevanceAssessment;
  eligible: boolean;
  invite: CanInviteResult;
}

export interface ProposalCandidate {
  id: string;
  assessment: RelevanceAssessment;
  /** Always false: the organizer selects. Nothing is pre-approved. */
  selected: false;
}

/**
 * Builds the person part of a distribution proposal: only people who are
 * eligible, may be invited (which already requires the suggestion opt-in)
 * and have at least some relevance; ordered by relevance; capped.
 */
export function buildPersonCandidates(candidates: readonly PersonCandidateInput[], maxCandidates: number): ProposalCandidate[] {
  return candidates
    .filter((c) => c.eligible && c.invite.allowed && c.assessment.level !== 'NONE')
    .slice()
    .sort(compareRelevance)
    .slice(0, Math.max(0, maxCandidates))
    .map((c) => ({ id: c.id, assessment: c.assessment, selected: false as const }));
}

/** Upper bound for invitations in one run: the policy maximum, and never more than 3× the open places. */
export function invitationBudget(policy: DistributionPolicy, availablePlaces: number | null): number {
  if (availablePlaces === null) return policy.maxInvitationsPerRun;
  return Math.max(0, Math.min(policy.maxInvitationsPerRun, availablePlaces * 3));
}
