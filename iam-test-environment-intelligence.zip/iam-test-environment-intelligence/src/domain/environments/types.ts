/**
 * Environment Intelligence — domain types.
 *
 * Spec: AM_ENVIRONMENT_INTELLIGENCE_SPEC.md, AM_ACCESS_AUDIENCE_POLICY_SPEC.md,
 * AM_CAPACITY_DISTRIBUTION_SPEC.md, AM_CATEGORY_TAXONOMY_V1.md.
 *
 * Type-only module: no runtime code, so it can be imported from server code,
 * route handlers and tests without side effects. Deliberately no TypeScript
 * `enum`s (string unions instead), so the code also runs under Node's
 * built-in type stripping.
 */

export type EnvironmentKind = 'EVENT' | 'PROGRAM' | 'HUB' | 'PROJECT_SPACE';

export type EnvironmentStatus = 'DRAFT' | 'PUBLISHED' | 'UNPUBLISHED' | 'CANCELLED' | 'ARCHIVED';

export type AccessModel = 'PUBLIC' | 'PRIVATE' | 'CURATED' | 'COMMUNITY';
export type RegistrationMode = 'OPEN' | 'REQUEST' | 'INVITE_ONLY';
export type ApprovalMode = 'AUTO_WITHIN_CONDITIONS' | 'MANUAL' | 'INVITATION_ONLY';
export type CrossCommunityMode = 'NONE' | 'ON_REQUEST' | 'ALLOWED_HUBS';
export type GuestPolicy = 'NONE' | 'MEMBERS_PLUS_N';

export type OrganizerRole = 'OWNER' | 'CO_ORGANIZER' | 'CHECKIN_STAFF';

/** Participation statuses. NO_RESPONSE is never converted to DECLINED automatically. */
export type ParticipationStatus =
  | 'INVITED'
  | 'REQUESTED'
  | 'PENDING_APPROVAL'
  | 'CONFIRMED'
  | 'MAYBE'
  | 'DECLINED'
  | 'CANCELLED'
  | 'WAITLISTED'
  | 'CHECKED_IN'
  | 'NO_RESPONSE'
  | 'REMOVED';

export type ParticipationSource =
  | 'SELF'
  | 'INVITATION'
  | 'DISTRIBUTION'
  | 'WAITLIST_PROMOTION'
  | 'ORGANIZER_ADDED'
  | 'HUB_MEMBERSHIP';

export type ExperienceLevel = 'level.open' | 'level.beginner' | 'level.intermediate' | 'level.advanced' | 'level.expert';

/** Extra conditions for AUTO_WITHIN_CONDITIONS approval. All must hold. */
export type AutoCondition =
  | { type: 'hub_membership'; hubIds: string[] }
  | { type: 'profile_type'; audienceCodes: string[] }
  | { type: 'closes_hours_before_start'; hours: number };

/**
 * Closed set of admission rules. There is intentionally no rule type for
 * special-category data (health, religion, ethnicity, …), gender,
 * nationality, engagement or relevance.
 */
export type EligibilityRule =
  | { type: 'required_skill'; skillId: string; label: string; mustBeVerified: boolean }
  | { type: 'min_experience_level'; level: ExperienceLevel; skillId?: string }
  | { type: 'profile_type'; audienceCodes: string[] }
  | { type: 'hub_membership'; hubIds: string[]; label: string }
  | { type: 'organization_membership'; organizationIds: string[]; label: string }
  | { type: 'location'; countryCodes: string[] }
  | { type: 'prerequisite_environment'; environmentId: string; label: string }
  | { type: 'age_minimum'; years: number };

export interface AccessPolicy {
  version: number;
  accessModel: AccessModel;
  discoverable: boolean;
  registrationMode: RegistrationMode;
  approvalMode: ApprovalMode;
  autoConditions: AutoCondition[];
  eligibilityRules: EligibilityRule[];
  guestPolicy: GuestPolicy;
  guestsPerMember: number | null;
  communityHubIds: string[];
  crossCommunity: CrossCommunityMode;
  allowedPartnerHubIds: string[];
}

export interface EnvironmentForPolicy {
  id: string;
  kind: EnvironmentKind;
  status: EnvironmentStatus;
  /** ISO timestamp; null for ongoing environments such as hubs. */
  startsAt: string | null;
  policy: AccessPolicy;
}

/**
 * Everything the access decision needs to know about the actor, resolved
 * server-side from the session. Never built from request-body values.
 */
export interface ActorContext {
  /** null = anonymous visitor. */
  userId: string | null;
  isPlatformAdmin: boolean;
  /** Admin of the organization that owns the environment. */
  isOwningOrgAdmin: boolean;
  organizerRole: OrganizerRole | null;
  participationStatus: ParticipationStatus | null;
  hasOpenInvitation: boolean;
  hubIds: string[];
  /** A member of one of the community hubs named this actor as their guest. */
  isNominatedGuest: boolean;
}

export interface ProfileSkill {
  skillId: string;
  level: ExperienceLevel;
  verified: boolean;
}

/**
 * The declared profile data matching and eligibility may use. There are
 * deliberately no behavioural fields (views, clicks, inactivity, past
 * declines): those must never influence relevance or eligibility.
 */
export interface ProfileContext {
  userId: string;
  profileContextId: string | null;
  audienceCodes: string[];
  interestCodes: string[];
  purposeCodes: string[];
  skills: ProfileSkill[];
  countryCode: string | null;
  city: string | null;
  hubIds: string[];
  organizationIds: string[];
  completedEnvironmentIds: string[];
  birthYear: number | null;
}

/** Taxonomy view of an environment, for relevance. */
export interface EnvironmentAudienceProfile {
  categoryCodes: string[];
  audienceCodes: string[];
  purposeCodes: string[];
  targetSkillIds: string[];
  communityHubIds: string[];
  locationScope: 'scope.online' | 'scope.local' | 'scope.regional' | 'scope.national' | 'scope.international';
  city: string | null;
  countryCode: string | null;
}

export type DistributionMode =
  | 'NONE'
  | 'SUGGEST_INTERESTED'
  | 'SUGGEST_HUBS'
  | 'SUGGEST_ORGANIZATIONS'
  | 'SUGGEST_ALL';

export type DistributionApprovalMethod =
  | 'AUTO_REGISTER_WITHIN_CONDITIONS'
  | 'MANUAL_APPROVAL'
  | 'PERSONAL_INVITATION_ONLY';

export type TriggerDefinition =
  | { type: 'AVAILABLE_BELOW'; places: number }
  | { type: 'UTILISATION_BELOW'; percent: number; checkAtHoursBeforeStart: number }
  | { type: 'CANCELLATION'; minCount: number }
  | { type: 'WAITLIST_ACTIVATED' }
  | { type: 'CAPACITY_INCREASED' };

export interface DistributionPolicy {
  version: number;
  mode: DistributionMode;
  approvalMethod: DistributionApprovalMethod;
  triggers: TriggerDefinition[];
  maxInvitationsPerRun: number;
  minHoursBeforeStart: number;
}

export type InvitationKind = 'PERSONAL' | 'HUB' | 'ORGANIZATION' | 'DISTRIBUTION_SUGGESTION';
export type InvitationChannel = 'IN_APP' | 'EMAIL' | 'NONE';
